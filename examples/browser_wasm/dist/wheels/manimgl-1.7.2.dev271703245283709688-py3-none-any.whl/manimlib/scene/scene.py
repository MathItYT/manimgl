from __future__ import annotations

from collections import OrderedDict
import platform
import random
import time
import subprocess
import sys
import inspect
from functools import wraps
from contextlib import contextmanager
from contextlib import ExitStack

import numpy as np
from tqdm.auto import tqdm as ProgressDisplay

from manimlib.animation.animation import prepare_animation
from manimlib.animation.animation import prepare_animation_async
from manimlib.camera.camera import Camera
from manimlib.camera.camera_frame import CameraFrame
from manimlib.config import manim_config
from manimlib.event_handler import EVENT_DISPATCHER
from manimlib.event_handler.event_type import EventType
from manimlib.event_keys import Keys
from manimlib.event_keys import Mods
from manimlib.logger import log
from manimlib.mobject.mobject import _AnimationBuilder
from manimlib.mobject.mobject import Group
from manimlib.mobject.mobject import Mobject
from manimlib.mobject.mobject import Point
from manimlib.mobject.types.vectorized_mobject import VGroup
from manimlib.mobject.types.vectorized_mobject import VMobject
if sys.platform != "emscripten":
    from manimlib.scene.scene_embed import InteractiveSceneEmbed
    from manimlib.scene.scene_embed import CheckpointManager
from manimlib.scene.scene_file_writer import SceneFileWriter
from manimlib.utils.dict_ops import merge_dicts_recursively
from manimlib.utils.family_ops import extract_mobject_family_members
from manimlib.utils.family_ops import recursive_mobject_remove
from manimlib.utils.sounds import play_sound
from manimlib.utils.sounds import get_full_sound_file_path

if sys.platform == "emscripten":
    from manimlib.utils.browser_audio import browser_audio
from manimlib.utils.color import color_to_rgba
from manimlib.window import Window

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Callable, Iterable, TypeVar, Optional
    from manimlib.typing import Vect3

    T = TypeVar('T')

    from PIL.Image import Image

    from manimlib.animation.animation import Animation


class Scene(object):
    random_seed: int = 0
    pan_sensitivity: float = 0.5
    scroll_sensitivity: float = 20
    drag_to_pan: bool = True
    max_num_saved_states: int = 50
    default_camera_config: dict = dict()
    default_file_writer_config: dict = dict()
    samples = 0
    # Euler angles, in degrees
    default_frame_orientation = (0, 0)

    def __init__(
        self,
        window: Optional[Window] = None,
        camera_config: dict = dict(),
        file_writer_config: dict = dict(),
        skip_animations: bool = False,
        always_update_mobjects: bool = False,
        start_at_animation_number: int | None = None,
        end_at_animation_number: int | None = None,
        show_animation_progress: bool = False,
        leave_progress_bars: bool = False,
        preview_while_skipping: bool = True,
        presenter_mode: bool = False,
        default_wait_time: float = 1.0,
        invert_zoom_scroll: bool = False,
    ):
        self.skip_animations = skip_animations
        self.always_update_mobjects = always_update_mobjects
        self.start_at_animation_number = start_at_animation_number
        self.end_at_animation_number = end_at_animation_number
        self.show_animation_progress = show_animation_progress
        self.leave_progress_bars = leave_progress_bars
        self.preview_while_skipping = preview_while_skipping
        self.presenter_mode = presenter_mode
        self.default_wait_time = default_wait_time
        self.invert_zoom_scroll = invert_zoom_scroll

        self.camera_config = merge_dicts_recursively(
            manim_config.camera,         # Global default
            self.default_camera_config,  # Updated configuration that subclasses may specify
            camera_config,               # Updated configuration from instantiation
        )
        self.file_writer_config = merge_dicts_recursively(
            manim_config.file_writer,
            self.default_file_writer_config,
            file_writer_config,
        )

        self.window = window
        if self.window:
            self.window.init_for_scene(self)
            # Make sure the camera and the window sync
            # self.camera_config["fps"] = 30

        # Core state of the scene
        self.camera: Camera = Camera(
            window=self.window,
            samples=self.samples,
            **self.camera_config
        )
        self.frame: CameraFrame = self.camera.frame
        self.frame.reorient(*self.default_frame_orientation)
        self.frame.make_orientation_default()

        self.file_writer = SceneFileWriter(self, **self.file_writer_config)
        self.mobjects: list[Mobject] = [self.camera.frame]
        self.id_to_mobject_map: dict[int, Mobject] = dict()
        self.num_plays: int = 0
        self.time: float = 0
        self.max_time: float = 0
        self.skip_time: float = 0
        self.original_skipping_status: bool = self.skip_animations
        self.undo_stack = []
        self.redo_stack = []

        if self.start_at_animation_number is not None:
            self.skip_animations = True
        if self.file_writer.has_progress_display():
            self.show_animation_progress = False

        # Items associated with interaction
        self.mouse_point = Point()
        self.mouse_drag_point = Point()
        self.hold_on_wait = self.presenter_mode
        self.quit_interaction = False
        self._active_sound_processes: list[subprocess.Popen] = []
        self._interactive_sound_events: list[tuple[float, str, float]] = []

        # Much nicer to work with deterministic scenes
        if self.random_seed is not None:
            random.seed(self.random_seed)
            np.random.seed(self.random_seed)

        # Seek controls
        self.should_end_playing: bool = False
        self.checkpoints: list[tuple[SceneState, list[Animation], float, Optional[Callable[[], bool]]]] = []
        self.paused: bool = False
        self.current_checkpoint: Optional[int] = None

    def __str__(self) -> str:
        return self.__class__.__name__

    def get_window(self) -> Window | None:
        return self.window

    def run(self) -> None:
        """Run the scene on native platforms; browser scenes use build_async()."""
        if sys.platform == "emscripten":
            raise RuntimeError(
                "Use await run_scene_from_class(...) for Pyodide scenes"
            )
        self.build()
        self.playback()

    def _begin_build(self) -> None:
        self.virtual_animation_start_time = 0
        self.real_animation_start_time = time.time()
        self.file_writer.begin()
        self.setup()

    def build(self):
        if sys.platform == "emscripten":
            raise RuntimeError("Use await build_async() in Pyodide")
        self._begin_build()
        try:
            self.construct()
        except EndScene:
            pass
        except KeyboardInterrupt:
            print("", end="\r")
            self.file_writer.ended_with_interrupt = True
        return self

    async def build_async(self):
        """Construct a browser scene without blocking the event loop."""
        if sys.platform != "emscripten":
            return self.build()
        self._begin_build()
        try:
            result = self.construct()
            if inspect.isawaitable(result):
                await result
        except EndScene:
            pass
        except KeyboardInterrupt:
            print("", end="\r")
            self.file_writer.ended_with_interrupt = True
        return self

    async def run_live(self):
        """Run a browser scene directly, keeping computation and rendering live."""
        if sys.platform != "emscripten":
            return self.run()

        self.virtual_animation_start_time = 0
        self.real_animation_start_time = time.time()
        self.file_writer.begin()
        self.setup()

        try:
            result = self.construct()
            if inspect.isawaitable(result):
                await result
        except EndScene:
            pass
        except KeyboardInterrupt:
            print("", end="\r")
            self.file_writer.ended_with_interrupt = True

        # Present the final live scene automatically. Explicit browser_present()
        # calls are no longer required from user scenes.
        await self.update_frame_async(force_draw=True)
        self.window.poll_events()
        await self._browser_frame()
        await self.browser_interaction_loop()

    def playback(self) -> None:
        if sys.platform == "emscripten":
            raise RuntimeError("Use await scene.playback_async() in Pyodide")
        try:
            self.interact()
        finally:
            self.tear_down()

    async def playback_async(self, repeat: bool = False) -> None:
        if sys.platform != "emscripten":
            raise RuntimeError("playback_async() is only available in Pyodide")
        await self.browser_playback_loop(repeat=repeat)

    def setup(self) -> None:
        """
        This is meant to be implement by any scenes which
        are comonly subclassed, and have some common setup
        involved before the construct method is called.
        """
        pass

    def construct(self) -> None:
        # Where all the animation happens
        # To be implemented in subclasses
        pass

    def stop_sound_processes(self) -> None:
        for process in self._active_sound_processes:
            if process.poll() is None:
                process.terminate()
        self._active_sound_processes.clear()

    def replay_interactive_sounds(self, scene_time: float) -> None:
        if self.window is None:
            return

        for event_time, sound_file, duration in self._interactive_sound_events:
            elapsed = scene_time - event_time
            if elapsed >= duration:
                continue
            process = play_sound(sound_file, max(0.0, elapsed))
            self._active_sound_processes.append(process)

    def tear_down(self) -> None:
        self.stop_sound_processes()
        self.stop_skipping()
        self.file_writer.finish()
        if self.window:
            self.window.destroy()
            self.window = None

    def interact(self) -> None:
        """
        If there is a window, enter a loop which updates the frame, each of those
        pulling whatever events the window has to report
        """
        if self.window is None:
            return
        # In the browser, rendercanvas owns the event loop. Blocking here with a
        # Python while-loop would prevent requestAnimationFrame and DOM events from running.
        if sys.platform == "emscripten":
            return
        log.info(
            "\nTips: Using the keys `d`, `f`, or `z` " +
            "you can interact with the scene. " +
            "Press `command + q` or `esc` to quit"
        )
        self.skip_animations = False
        while not self.is_window_closing():
            self.update_frame(1 / self.camera.fps)

    def embed(
        self,
        close_scene_on_exit: bool = True,
        show_animation_progress: bool = False,
    ) -> None:
        if not self.window:
            # Embed is only relevant for interactive development with a Window
            return
        self.show_animation_progress = show_animation_progress
        self.stop_skipping()
        self.update_frame(force_draw=True)

        InteractiveSceneEmbed(self).launch()

        # End scene when exiting an embed
        if close_scene_on_exit:
            raise EndScene()

    # Only these methods should touch the camera

    def get_image(self) -> Image:
        if self.window is None:
            return self.camera.get_image()
        # A window has the camera drawing at its size, so the frame has to be drawn again
        # at the resolution an image of it is meant to come out at
        with self.camera.at_output_resolution():
            self.camera.capture(*self.mobjects)
            return self.camera.get_image()

    def show(self) -> None:
        self.update_frame(force_draw=True)
        self.get_image().show()

    def progress_current_checkpoint(self, dt: float) -> None:
        if self.current_checkpoint is None:
            return

        current_checkpoint = self.checkpoints[self.current_checkpoint]
        animations = current_checkpoint[1]
        start_time = current_checkpoint[0].time
        duration = current_checkpoint[2]
        end_time = start_time + duration

        if self.time >= end_time:
            self.finish_animations(animations)
            self.post_play()
            if self.current_checkpoint + 1 < len(self.checkpoints):
                self.current_checkpoint += 1
                next_checkpoint = self.checkpoints[self.current_checkpoint]
                self.restore_state(next_checkpoint[0])
                
                # Sincronizar reloj para el nuevo checkpoint
                self.virtual_animation_start_time = self.time
                self.real_animation_start_time = time.time()
            else:
                self.current_checkpoint = None
            return

        for animation in animations:
            animation.update_reference_mobjects(dt, frame_rate=self.camera.fps)
            alpha = (self.time - start_time) / duration if duration > 0 else 1.0
            animation.interpolate(float(np.clip(alpha, 0.0, 1.0)))

    def update_frame(self, dt: float = 0, force_draw: bool = False) -> None:
        if not self.paused:
            self.increment_time(dt)
            self.progress_current_checkpoint(dt)
            self.update_mobjects(dt)
        self.draw_frame(dt, force_draw)

    async def update_frame_async(self, dt: float = 0, force_draw: bool = False) -> None:
        if not self.paused:
            self.increment_time(dt)
            self.progress_current_checkpoint(dt)
            await self.update_mobjects_async(dt)
        self.draw_frame(dt, force_draw)

    def draw_frame(self, dt: float = 0, force_draw: bool = False) -> None:
        if self.skip_animations and not force_draw:
            return

        if self.is_window_closing():
            raise EndScene()

        if self.window and dt == 0 and not self.window.has_undrawn_event() and not force_draw:
            # In this case, there's no need for new rendering, but we
            # shoudl still listen for new events
            self.window.poll_events()
            return

        self.camera.renderer.post_processor.time = self.time
        self.camera.capture(*self.mobjects)

        if self.window and not self.skip_animations:
            vt = self.time - self.virtual_animation_start_time
            rt = time.time() - self.real_animation_start_time
            if sys.platform != "emscripten":
                time.sleep(max(vt - rt, 0))

    def emit_frame(self) -> None:
        if not self.skip_animations:
            self.file_writer.write_frame()

    # Related to updating

    def update_mobjects(self, dt: float) -> None:
        for mobject in self.mobjects:
            mobject.update(dt, frame_rate=self.camera.fps)

    async def update_mobjects_async(self, dt: float) -> None:
        for mobject in self.mobjects:
            await mobject.update_async(dt, frame_rate=self.camera.fps)

    def should_update_mobjects(self) -> bool:
        return self.always_update_mobjects or any(
            mob.has_updaters() for mob in self.mobjects
        )

    # Related to time
    def get_max_time(self) -> float:
        return self.max_time

    def get_time(self) -> float:
        return self.time

    def increment_time(self, dt: float) -> None:
        self.time += dt
        self.max_time = max(self.max_time, self.time)

    # Related to internal mobject organization

    def get_top_level_mobjects(self) -> list[Mobject]:
        # Return only those which are not in the family
        # of another mobject from the scene
        mobjects = self.get_mobjects()
        families = [m.get_family() for m in mobjects]

        def is_top_level(mobject):
            num_families = sum([
                (mobject in family)
                for family in families
            ])
            return num_families == 1
        return list(filter(is_top_level, mobjects))

    def get_mobject_family_members(self) -> list[Mobject]:
        return extract_mobject_family_members(self.mobjects)

    @staticmethod
    def affects_mobject_list(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            func(self, *args, **kwargs)
            return self
        return wrapper

    @affects_mobject_list
    def add(self, *new_mobjects: Mobject):
        """
        Mobjects will be displayed, from background to
        foreground in the order with which they are added.
        """
        self.remove(*new_mobjects)
        self.mobjects += new_mobjects
        # No reordering by z_index here: this list stays in the order things were added, and
        # the renderer settles what a z_index has to say about drawing order, see
        # Renderer.resolve
        self.id_to_mobject_map.update({
            id(sm): sm
            for m in new_mobjects
            for sm in m.get_family()
        })
        return self

    def add_mobjects_among(self, values: Iterable):
        """
        This is meant mostly for quick prototyping,
        e.g. to add all mobjects defined up to a point,
        call self.add_mobjects_among(locals().values())
        """
        self.add(*filter(
            lambda m: isinstance(m, Mobject),
            values
        ))
        return self

    @affects_mobject_list
    def replace(self, mobject: Mobject, *replacements: Mobject):
        if mobject in self.mobjects:
            index = self.mobjects.index(mobject)
            self.mobjects = [
                *self.mobjects[:index],
                *replacements,
                *self.mobjects[index + 1:]
            ]
        return self

    @affects_mobject_list
    def remove(self, *mobjects_to_remove: Mobject):
        """
        Removes anything in mobjects from scenes mobject list, but in the event that one
        of the items to be removed is a member of the family of an item in mobject_list,
        the other family members are added back into the list.

        For example, if the scene includes Group(m1, m2, m3), and we call scene.remove(m1),
        the desired behavior is for the scene to then include m2 and m3 (ungrouped).
        """
        to_remove = set(extract_mobject_family_members(mobjects_to_remove))
        new_mobjects, _ = recursive_mobject_remove(self.mobjects, to_remove)
        self.mobjects = new_mobjects

    @affects_mobject_list
    def remove_all_except(self, *mobjects_to_keep : Mobject):
        self.clear()
        self.add(*mobjects_to_keep)

    def bring_to_front(self, *mobjects: Mobject):
        self.add(*mobjects)
        return self

    @affects_mobject_list
    def bring_to_back(self, *mobjects: Mobject):
        self.remove(*mobjects)
        self.mobjects = list(mobjects) + self.mobjects
        return self

    @affects_mobject_list
    def clear(self):
        self.mobjects = []
        return self

    def get_mobjects(self) -> list[Mobject]:
        return list(self.mobjects)

    def get_mobject_copies(self) -> list[Mobject]:
        return [m.copy() for m in self.mobjects]

    def point_to_mobject(
        self,
        point: np.ndarray,
        search_set: Iterable[Mobject] | None = None,
        buff: float = 0
    ) -> Mobject | None:
        """
        E.g. if clicking on the scene, this returns the top layer mobject
        under a given point
        """
        if search_set is None:
            search_set = self.mobjects
        for mobject in reversed(search_set):
            if mobject.is_point_touching(point, buff=buff):
                return mobject
        return None

    def get_group(self, *mobjects):
        if all(isinstance(m, VMobject) for m in mobjects):
            return VGroup(*mobjects)
        else:
            return Group(*mobjects)

    def id_to_mobject(self, id_value):
        return self.id_to_mobject_map[id_value]

    def ids_to_group(self, *id_values):
        return self.get_group(*filter(
            lambda x: x is not None,
            map(self.id_to_mobject, id_values)
        ))

    def i2g(self, *id_values):
        return self.ids_to_group(*id_values)

    def i2m(self, id_value):
        return self.id_to_mobject(id_value)

    # Related to skipping

    def update_skipping_status(self) -> None:
        if self.start_at_animation_number is not None:
            if self.num_plays == self.start_at_animation_number:
                self.skip_time = self.time
                if not self.original_skipping_status:
                    self.stop_skipping()
        if self.end_at_animation_number is not None:
            if self.num_plays >= self.end_at_animation_number:
                raise EndScene()

    def stop_skipping(self) -> None:
        self.virtual_animation_start_time = self.time
        self.real_animation_start_time = time.time()
        self.skip_animations = False

    # Methods associated with running animations

    def get_time_progression(
        self,
        run_time: float,
        n_iterations: int | None = None,
        desc: str = "",
        override_skip_animations: bool = False
    ) -> list[float] | np.ndarray | ProgressDisplay:
        if self.skip_animations and not override_skip_animations:
            return [run_time]

        times = np.arange(0, run_time, 1 / self.camera.fps) + 1 / self.camera.fps

        self.file_writer.set_progress_display_description(sub_desc=desc)

        if self.show_animation_progress:
            return ProgressDisplay(
                times,
                total=n_iterations,
                leave=self.leave_progress_bars,
                ascii=True if platform.system() == 'Windows' else None,
                desc=desc,
                bar_format="{l_bar} {n_fmt:3}/{total_fmt:3} {rate_fmt}{postfix}",
            )
        else:
            return times

    def get_run_time(self, animations: Iterable[Animation]) -> float:
        return np.max([animation.get_run_time() for animation in animations])

    def get_animation_time_progression(
        self,
        animations: Iterable[Animation]
    ) -> list[float] | np.ndarray | ProgressDisplay:
        animations = list(animations)
        run_time = self.get_run_time(animations)
        description = f"{self.num_plays} {animations[0]}"
        if len(animations) > 1:
            description += ", etc."
        time_progression = self.get_time_progression(run_time, desc=description)
        return time_progression

    def get_wait_time_progression(
        self,
        duration: float,
        stop_condition: Callable[[], bool] | None = None
    ) -> list[float] | np.ndarray | ProgressDisplay:
        kw = {"desc": f"{self.num_plays} Waiting"}
        if stop_condition is not None:
            kw["n_iterations"] = -1  # So it doesn't show % progress
            kw["override_skip_animations"] = True
        return self.get_time_progression(duration, **kw)

    def pre_play(self):
        # Browser code must use _hold_loop_async() from async entry points.
        if self.presenter_mode and self.num_plays == 0 and sys.platform != "emscripten":
            self.hold_loop()

        self.update_skipping_status()

        if not self.skip_animations:
            self.file_writer.begin_animation()

        if self.window:
            self.virtual_animation_start_time = self.time
            self.real_animation_start_time = time.time()

    def post_play(self):
        if not self.skip_animations:
            self.file_writer.end_animation()

        if self.preview_while_skipping and self.skip_animations and self.window is not None:
            # Show some quick frames along the way
            self.update_frame(dt=0, force_draw=True)

        self.num_plays += 1

    def begin_animations(self, animations: Iterable[Animation]) -> None:
        all_mobjects = set(self.get_mobject_family_members())
        for animation in animations:
            animation.begin()
            # Anything animated that's not already in the
            # scene gets added to the scene.  Note, for
            # animated mobjects that are in the family of
            # those on screen, this can result in a restructuring
            # of the scene.mobjects list, which is usually desired.
            # A group holding nothing but mobjects already on screen is
            # itself already on screen, though, and restructuring for its
            # sake would cost its ancestors whatever points they draw
            # themselves, so leave the scene as it is.
            family = animation.mobject.get_family()
            drawn = [mob for mob in family if mob.has_points()]
            shown_already = len(drawn) > 0 and all(mob in all_mobjects for mob in drawn)
            if animation.mobject not in all_mobjects and not shown_already:
                self.add(animation.mobject)
                all_mobjects = all_mobjects.union(family)

    def progress_through_animations(self, animations: Iterable[Animation]) -> bool:
        last_t = 0
        for t in self.get_animation_time_progression(animations):
            if self.should_end_playing:
                self.should_end_playing = False
                return False
            dt = t - last_t
            last_t = t
            # The clock moves before anything else in the frame, so that time
            # based updaters are evaluated at the moment the frame stands for.
            self.increment_time(dt)
            if sys.platform == "emscripten":
                browser_audio.sync(self.time, self._interactive_sound_events)
            for animation in animations:
                animation.update_reference_mobjects(dt, frame_rate=self.camera.fps)
                alpha = t / animation.run_time
                animation.interpolate(alpha)
            # Updaters on the mobjects themselves have the last word, applied
            # on top of whatever the animations just interpolated
            self.update_mobjects(dt)
            self.draw_frame(dt)
            self.emit_frame()
        return True

    def finish_animations(self, animations: Iterable[Animation]) -> None:
        for animation in animations:
            animation.finish()
            animation.clean_up_from_scene(self)
        # Note that the passage of time during the animation, including
        # for the case of skipped animations, is handled by
        # progress_through_animations
        self.update_mobjects(0)

    def pause(self) -> None:
        self.paused = True

    def resume(self) -> None:
        self.paused = False

    def seek(self, t: float, sync_audio: bool = True) -> None:
        if t < 0:
            t = 0.0
        if t > self.max_time:
            t = self.max_time

        if self.current_checkpoint is None:
            self.should_end_playing = True

        idx = None
        for i in range(len(self.checkpoints) - 1, -1, -1):
            state = self.checkpoints[i][0]
            if state.time <= t:
                idx = i
                break

        if idx is None:
            return

        self.stop_sound_processes()

        self.current_checkpoint = idx
        state, animations, duration, _ = self.checkpoints[idx]

        # 1. Restaurar estado de los mobjects al inicio del checkpoint
        self.restore_state(state)

        # 2. Interpolar al punto t deseado
        if animations:
            alpha = (t - state.time) / duration if duration > 0 else 1.0
            alpha = float(np.clip(alpha, 0.0, 1.0))
            for anim in animations:
                anim.interpolate(alpha)

        # 3. Asignar el nuevo tiempo
        self.time = t
        self.update_mobjects(t - state.time)

        # 4. SINCRONIZACIÓN DE RELOJ: Re-anclar el tiempo virtual al real
        self.virtual_animation_start_time = self.time
        self.real_animation_start_time = time.time()

        # In headless mode, frames are written to a movie without a playback
        # clock. After a seek, the scene clock and the output timeline can
        # differ, so keep audio events aligned with the frame currently being
        # rendered rather than with the absolute scene time.
        if self.window is None:
            output_time = self.file_writer.get_output_time()
            self.file_writer.set_audio_time_offset(self.time - output_time)
            self.file_writer.replay_audio_from(self.time)
        elif sys.platform == "emscripten":
            if sync_audio:
                browser_audio.seek(self.time, self._interactive_sound_events)
        else:
            self.replay_interactive_sounds(self.time)

        self.draw_frame(force_draw=True)
        self.should_begin_animations = False

    async def seek_async(self, t: float, sync_audio: bool = True) -> None:
        if sys.platform != "emscripten":
            self.seek(t, sync_audio=sync_audio)
            return
        t = float(np.clip(t, 0.0, self.max_time))
        if self.current_checkpoint is None:
            self.should_end_playing = True
        idx = None
        for i in range(len(self.checkpoints) - 1, -1, -1):
            if self.checkpoints[i][0].time <= t:
                idx = i
                break
        if idx is None:
            return
        self.stop_sound_processes()
        self.current_checkpoint = idx
        state, animations, duration, _ = self.checkpoints[idx]
        self.restore_state(state)
        if animations:
            alpha = (t - state.time) / duration if duration > 0 else 1.0
            for anim in animations:
                anim.interpolate(float(np.clip(alpha, 0.0, 1.0)))
        self.time = t
        await self.update_mobjects_async(t - state.time)
        self.virtual_animation_start_time = self.time
        self.real_animation_start_time = time.time()
        if sync_audio:
            browser_audio.seek(self.time, self._interactive_sound_events)
        self.draw_frame(force_draw=True)
        self.should_begin_animations = False

    def play(
        self,
        *proto_animations: Animation | _AnimationBuilder,
        run_time: float | None = None,
        rate_func: Callable[[float], float] | None = None,
        lag_ratio: float | None = None,
        register: bool = True
    ) -> None:
        if len(proto_animations) == 0:
            log.warning("Called Scene.play with no animations")
            return
        animations = list(map(prepare_animation, proto_animations))
        for anim in animations:
            anim.update_rate_info(run_time, rate_func, lag_ratio)
        self.pre_play()
        self.begin_animations(animations)
        if register:
            self.checkpoints.append((self.get_state(ignore=[self.camera.frame]), animations, run_time or self.get_run_time(animations), None))
        no_interrupt = self.progress_through_animations(animations)
        if not no_interrupt and register:
            while self.current_checkpoint is not None:
                self.update_frame(dt=1 / self.camera.fps)
                self.emit_frame()
            return
        self.finish_animations(animations)
        self.post_play()

    async def _browser_frame(self) -> float | None:
        """Yield to the browser and return the frame timestamp in seconds."""
        if sys.platform != "emscripten":
            return None
        from manimlib.utils.browser_scheduler import next_animation_frame
        return await next_animation_frame()

    async def play_async(
        self,
        *proto_animations: Animation | _AnimationBuilder,
        run_time: float | None = None,
        rate_func: Callable[[float], float] | None = None,
        lag_ratio: float | None = None,
        register: bool = True,
    ) -> None:
        """Play an animation without blocking the browser event loop."""
        if sys.platform != "emscripten":
            return self.play(*proto_animations, run_time=run_time, rate_func=rate_func,
                             lag_ratio=lag_ratio, register=register)
        if not proto_animations:
            log.warning("Called Scene.play_async with no animations")
            return
        animations = [await prepare_animation_async(anim) for anim in proto_animations]
        for anim in animations:
            anim.update_rate_info(run_time, rate_func, lag_ratio)
        if self.presenter_mode and self.num_plays == 0:
            await self.hold_loop_async()
        self.pre_play()
        self.begin_animations(animations)
        duration = run_time or self.get_run_time(animations)
        if register:
            self.checkpoints.append((self.get_state(ignore=[self.camera.frame]), animations, duration, None))
        # requestAnimationFrame is the browser clock. The configured render FPS
        # controls update granularity, not elapsed wall-clock time.
        last_frame_time = await self._browser_frame()
        elapsed = 0.0
        while elapsed < duration:
            self.window.poll_events()
            if self.should_end_playing:
                self.should_end_playing = False
                break
            frame_time = await self._browser_frame()
            wall_dt = max(0.0, float(frame_time - last_frame_time))
            last_frame_time = frame_time
            dt = min(wall_dt, max(0.0, duration - elapsed))
            if dt <= 0:
                continue

            # Do not gate interactive Scene.play() animations on the media clock.
            # Keyboard-triggered animations (for example resetting the camera frame)
            # must remain responsive even if a scene sound is paused, delayed, or
            # rejected by the browser. The dedicated browser_playback_loop handles
            # audio/timeline synchronization; an interactive animation must not wait
            # indefinitely for an unrelated sound event.
            elapsed += dt
            self.increment_time(dt)
            for animation in animations:
                animation.update_reference_mobjects(dt, frame_rate=self.camera.fps)
                animation.interpolate(float(elapsed) / animation.run_time)
            await self.update_mobjects_async(dt)
            browser_audio.sync(self.time, self._interactive_sound_events)
            self.draw_frame(dt, force_draw=True)
            self.emit_frame()
        self.finish_animations(animations)
        self.post_play()

    async def wait_async(
        self,
        duration: float | None = None,
        stop_condition: Callable[[], bool] | None = None,
        note: str | None = None,
        ignore_presenter_mode: bool = False,
        register: bool = True,
    ) -> None:
        """Wait asynchronously, using elapsed browser time as the clock."""
        if sys.platform != "emscripten":
            return self.wait(
                duration=duration,
                stop_condition=stop_condition,
                note=note,
                ignore_presenter_mode=ignore_presenter_mode,
                register=register,
            )

        duration = self.default_wait_time if duration is None else max(0.0, duration)
        if self.presenter_mode and self.num_plays == 0:
            await self.hold_loop_async()
        self.pre_play()
        await self.update_mobjects_async(0)

        presenter_wait = (
            self.presenter_mode
            and not self.skip_animations
            and not ignore_presenter_mode
        )
        if presenter_wait:
            if note:
                log.info(note)
            await self.hold_loop_async()
        else:
            if register:
                self.checkpoints.append((
                    self.get_state(ignore=[self.camera.frame]),
                    [],
                    duration or self.default_wait_time,
                    stop_condition,
                ))

            # Do not advance by a fixed 1 / camera.fps per requestAnimationFrame:
            # the browser may deliver RAF callbacks at a different rate (e.g.
            # 60 Hz while camera.fps is 30), which made waits finish too early.
            last_frame_time = await self._browser_frame()
            elapsed = 0.0
            while elapsed < duration:
                self.window.poll_events()
                if self.should_end_playing and register:
                    self.should_end_playing = False
                    last_frame_time = await self._browser_frame()
                    while self.current_checkpoint is not None:
                        frame_time = await self._browser_frame()
                        dt = max(0.0, float(frame_time - last_frame_time))
                        last_frame_time = frame_time
                        if dt <= 0.0:
                            continue
                        if not browser_audio.can_advance_scene(
                            self.time, self.time + dt, self._interactive_sound_events
                        ):
                            continue
                        await self.update_frame_async(dt=dt, force_draw=True)
                        browser_audio.sync(self.time, self._interactive_sound_events)
                        self.emit_frame()
                    self.post_play()
                    return

                frame_time = await self._browser_frame()
                wall_dt = max(0.0, float(frame_time - last_frame_time))
                last_frame_time = frame_time
                dt = min(wall_dt, max(0.0, duration - elapsed))
                if dt <= 0:
                    continue

                if not browser_audio.can_advance_scene(
                    self.time, self.time + dt, self._interactive_sound_events
                ):
                    continue

                elapsed += dt
                await self.update_frame_async(dt, force_draw=True)
                browser_audio.sync(self.time, self._interactive_sound_events)
                self.emit_frame()
                if stop_condition is not None and stop_condition():
                    break
        self.post_play()

    async def hold_loop_async(self) -> None:
        """Browser equivalent of hold_loop(), without blocking the event loop."""
        if sys.platform != "emscripten":
            return self.hold_loop()
        last_frame_time = await self._browser_frame()
        while self.hold_on_wait:
            self.window.poll_events()
            frame_time = await self._browser_frame()
            dt = max(0.0, float(frame_time - last_frame_time))
            last_frame_time = frame_time
            if dt <= 0.0:
                continue
            if not browser_audio.can_advance_scene(
                self.time, self.time + dt, self._interactive_sound_events
            ):
                continue
            await self.update_frame_async(dt=dt, force_draw=True)
            browser_audio.sync(self.time, self._interactive_sound_events)
        self.hold_on_wait = True

    def wait(
        self,
        duration: Optional[float] = None,
        stop_condition: Callable[[], bool] = None,
        note: str = None,
        ignore_presenter_mode: bool = False,
        register: bool = True
    ):
        if duration is None:
            duration = self.default_wait_time
        self.pre_play()
        self.update_mobjects(dt=0)  # Any problems with this?
        if self.presenter_mode and not self.skip_animations and not ignore_presenter_mode:
            if note:
                log.info(note)
            self.hold_loop()
        else:
            if register:
                self.checkpoints.append((self.get_state(ignore=[self.camera.frame]), [], duration or self.default_wait_time, stop_condition))
            time_progression = self.get_wait_time_progression(duration, stop_condition)
            last_t = 0
            for t in time_progression:
                if self.should_end_playing and register:
                    self.should_end_playing = False
                    while self.current_checkpoint is not None:
                        self.update_frame(dt=1 / self.camera.fps)
                        self.emit_frame()
                    return
                dt = t - last_t
                last_t = t
                self.update_frame(dt)
                self.emit_frame()
                if stop_condition is not None and stop_condition():
                    break
        self.post_play()

    def hold_loop(self):
        while self.hold_on_wait:
            self.update_frame(dt=1 / self.camera.fps)
        self.hold_on_wait = True

    def wait_until(
        self,
        stop_condition: Callable[[], bool],
        max_time: float = 60
    ):
        self.wait(max_time, stop_condition=stop_condition)

    def force_skipping(self):
        self.original_skipping_status = self.skip_animations
        self.skip_animations = True
        return self

    def revert_to_original_skipping_status(self):
        if hasattr(self, "original_skipping_status"):
            self.skip_animations = self.original_skipping_status
        return self

    def add_sound(
        self,
        sound_file: str,
        time_offset: float = 0,
        gain: float | None = None,
        gain_to_background: float | None = None
    ):
        if self.skip_animations:
            return

        if self.window is not None:
            event_time = self.get_time() + time_offset
            if sys.platform == "emscripten":
                # Register browser audio during scene construction. Playback starts
                # as the scene clock advances through each event's scheduled time.
                self._interactive_sound_events.append((event_time, sound_file, 0.0))
                browser_audio.register(sound_file)
            else:
                from pydub import AudioSegment
                duration = len(AudioSegment.from_file(get_full_sound_file_path(sound_file))) / 1000.0
                self._interactive_sound_events.append((event_time, sound_file, duration))
                process = play_sound(sound_file)
                self._active_sound_processes.append(process)
            return

        time = self.get_time() + time_offset
        self.file_writer.add_sound(sound_file, time, gain, gain_to_background)

    async def browser_playback_loop(self, repeat: bool = False) -> None:
        """Play the checkpoint timeline forward without seeking every frame.

        Audio and scene time share an advancing clock: if audio is ahead, its
        player is paused; if audio is behind, scene rendering is held until it
        catches up. Scene.seek/Scene.seek_async are not used for synchronization.
        """
        if sys.platform != "emscripten":
            raise RuntimeError("browser_playback_loop() is only available in Pyodide")
        from manimlib.utils.browser_scheduler import next_animation_frame

        if not self.checkpoints:
            browser_audio.stop_all()
            await self.update_frame_async(force_draw=True)
            return

        timeline_end = max(
            [float(self.max_time)]
            + [
                float(state.time) + max(0.0, float(duration))
                for state, _animations, duration, _stop_condition in self.checkpoints
            ]
        )

        while not self.is_window_closing():
            browser_audio.stop_all()
            self.should_end_playing = False

            # Restore the timeline's initial state once, not once per frame.
            active_index = 0
            for index, (state, _animations, _duration, _stop_condition) in enumerate(self.checkpoints):
                if state.time <= 0.0:
                    active_index = index
                else:
                    break

            state, animations, duration, _stop_condition = self.checkpoints[active_index]
            self.restore_state(state)
            scene_time = 0.0
            self.time = scene_time
            self.current_checkpoint = active_index
            for animation in animations:
                animation.interpolate(0.0)
            await self.update_mobjects_async(0.0)
            self.draw_frame(force_draw=True)
            browser_audio.sync(scene_time, self._interactive_sound_events)

            previous_frame_time = await next_animation_frame()
            while (
                not self.is_window_closing()
                and scene_time < timeline_end
                and not self.should_end_playing
            ):
                frame_time = await next_animation_frame()
                dt = max(0.0, float(frame_time - previous_frame_time))
                previous_frame_time = frame_time
                if dt <= 0.0:
                    continue

                proposed_time = min(scene_time + dt, timeline_end)
                if proposed_time <= scene_time:
                    break

                # If the proposed scene time would pass an audio media clock,
                # keep the current frame/time. If audio is ahead, BrowserAudio
                # pauses it until scene time catches up.
                if not browser_audio.can_advance_scene(
                    scene_time, proposed_time, self._interactive_sound_events
                ):
                    continue

                scene_dt = proposed_time - scene_time
                next_index = active_index
                for index, (checkpoint_state, _anims, _duration, _condition) in enumerate(self.checkpoints):
                    if checkpoint_state.time <= proposed_time:
                        next_index = index
                    else:
                        break

                if next_index != active_index:
                    state, animations, duration, _stop_condition = self.checkpoints[next_index]
                    self.restore_state(state)
                    active_index = next_index
                    self.current_checkpoint = active_index

                scene_time = proposed_time
                self.time = scene_time
                if animations:
                    segment_duration = max(0.0, float(duration))
                    alpha = (
                        float(np.clip((scene_time - state.time) / segment_duration, 0.0, 1.0))
                        if segment_duration > 0.0 else 1.0
                    )
                    for animation in animations:
                        animation.interpolate(alpha)

                await self.update_mobjects_async(scene_dt)
                self.draw_frame(scene_dt, force_draw=True)
                browser_audio.sync(scene_time, self._interactive_sound_events)

            self.should_end_playing = False
            if not repeat or self.is_window_closing():
                break

        browser_audio.stop_all()

    async def browser_interaction_loop(self) -> None:
        """Keep browser input and mobject updaters alive after playback."""
        if sys.platform != "emscripten":
            raise RuntimeError("browser_interaction_loop() is only available in Pyodide")
        from manimlib.utils.browser_scheduler import next_animation_frame
        from js import window

        previous_time = await next_animation_frame()
        # MotionBlur eases out over several rendered frames after input stops.
        # Keep drawing briefly after the last browser event so that release
        # frames are presented even when the scene has no active updaters.
        postprocess_settle_until = 0.0
        postprocess_settle_seconds = 0.5

        while not self.is_window_closing():
            current_time = await next_animation_frame()
            dt = max(0.0, current_time - previous_time)
            previous_time = current_time

            self.window.poll_events()
            has_undrawn_event = self.window.has_undrawn_event()

            # Keep the live canvas advancing while browser recording is active.
            # Otherwise a static scene draws only in response to input events,
            # so the recorder gets no frames throughout an idle interactive period.
            recording_active = bool(
                getattr(window, "__manimCaptureWebGPUFrame", None)
            )

            # requestAnimationFrame is the browser clock. Update animated scenes
            # as usual, and also draw every browser frame while recording so the
            # capture callback receives a continuous video timeline.
            if self.should_update_mobjects() or recording_active:
                await self.update_frame_async(dt=dt, force_draw=True)
            elif has_undrawn_event:
                postprocess_settle_until = (
                    current_time + postprocess_settle_seconds
                )
                await self.update_frame_async(force_draw=True)
            elif current_time < postprocess_settle_until:
                # Motion blur's temporal strength decays during these frames.
                await self.update_frame_async(dt=dt, force_draw=True)

    # Helpers for interactive development

    def get_state(self, ignore: list[Mobject] | None = None) -> SceneState:
        return SceneState(self, ignore=ignore)

    @affects_mobject_list
    def restore_state(self, scene_state: SceneState):
        scene_state.restore_scene(self)

    def save_state(self) -> None:
        state = self.get_state()
        if self.undo_stack and state.mobjects_match(self.undo_stack[-1]):
            return
        self.redo_stack = []
        self.undo_stack.append(state)
        if len(self.undo_stack) > self.max_num_saved_states:
            self.undo_stack.pop(0)

    def undo(self):
        if self.undo_stack:
            self.redo_stack.append(self.get_state())
            self.restore_state(self.undo_stack.pop())

    def redo(self):
        if self.redo_stack:
            self.undo_stack.append(self.get_state())
            self.restore_state(self.redo_stack.pop())

    @contextmanager
    def temp_skip(self):
        prev_status = self.skip_animations
        self.skip_animations = True
        try:
            yield
        finally:
            if not prev_status:
                self.stop_skipping()

    @contextmanager
    def temp_progress_bar(self):
        prev_progress = self.show_animation_progress
        self.show_animation_progress = True
        try:
            yield
        finally:
            self.show_animation_progress = prev_progress

    @contextmanager
    def temp_record(self):
        with self.camera.at_output_resolution():
            self.file_writer.begin_insert()
            try:
                yield
            finally:
                self.file_writer.end_insert()

    def temp_config_change(self, skip=False, record=False, progress_bar=False):
        stack = ExitStack()
        if skip:
            stack.enter_context(self.temp_skip())
        if record:
            stack.enter_context(self.temp_record())
        if progress_bar:
            stack.enter_context(self.temp_progress_bar())
        return stack

    def is_window_closing(self):
        return self.window and (self.window.is_closing or self.quit_interaction)

    # Event handling
    def set_floor_plane(self, plane: str = "xy"):
        if plane == "xy":
            self.frame.set_euler_axes("zxz")
        elif plane == "xz":
            self.frame.set_euler_axes("zxy")
        else:
            raise Exception("Only `xz` and `xy` are valid floor planes")

    def on_mouse_motion(
        self,
        point: Vect3,
        d_point: Vect3
    ) -> None:
        assert self.window is not None
        self.mouse_point.move_to(point)

        event_data = {"point": point, "d_point": d_point}
        propagate_event = EVENT_DISPATCHER.dispatch(EventType.MouseMotionEvent, **event_data)
        if propagate_event is not None and propagate_event is False:
            return

        frame = self.camera.frame
        # Handle perspective changes
        if self.window.is_key_pressed(ord(manim_config.key_bindings.pan_3d)):
            ff_d_point = frame.to_fixed_frame_point(d_point, relative=True)
            ff_d_point *= self.pan_sensitivity
            frame.increment_theta(-ff_d_point[0])
            frame.increment_phi(ff_d_point[1])
        # Handle frame movements
        elif self.window.is_key_pressed(ord(manim_config.key_bindings.pan)):
            frame.shift(-d_point)

    def on_mouse_drag(
        self,
        point: Vect3,
        d_point: Vect3,
        buttons: int,
        modifiers: int
    ) -> None:
        self.mouse_drag_point.move_to(point)
        if self.drag_to_pan:
            self.frame.shift(-d_point)

        event_data = {"point": point, "d_point": d_point, "buttons": buttons, "modifiers": modifiers}
        propagate_event = EVENT_DISPATCHER.dispatch(EventType.MouseDragEvent, **event_data)
        if propagate_event is not None and propagate_event is False:
            return

    def on_mouse_press(
        self,
        point: Vect3,
        button: int,
        mods: int
    ) -> None:
        self.mouse_drag_point.move_to(point)
        event_data = {"point": point, "button": button, "mods": mods}
        propagate_event = EVENT_DISPATCHER.dispatch(EventType.MousePressEvent, **event_data)
        if propagate_event is not None and propagate_event is False:
            return

    def on_mouse_release(
        self,
        point: Vect3,
        button: int,
        mods: int
    ) -> None:
        event_data = {"point": point, "button": button, "mods": mods}
        propagate_event = EVENT_DISPATCHER.dispatch(EventType.MouseReleaseEvent, **event_data)
        if propagate_event is not None and propagate_event is False:
            return

    def on_mouse_scroll(
        self,
        point: Vect3,
        offset: Vect3,
        x_pixel_offset: float,
        y_pixel_offset: float
    ) -> None:
        event_data = {"point": point, "offset": offset}
        propagate_event = EVENT_DISPATCHER.dispatch(EventType.MouseScrollEvent, **event_data)
        if propagate_event is not None and propagate_event is False:
            return

        rel_offset = -y_pixel_offset / self.camera.get_pixel_height()
        if self.invert_zoom_scroll:
            rel_offset *= -1
        self.frame.scale(
            1 - self.scroll_sensitivity * rel_offset,
            about_point=point
        )

    def on_key_release(
        self,
        symbol: int,
        modifiers: int
    ) -> None:
        event_data = {"symbol": symbol, "modifiers": modifiers}
        propagate_event = EVENT_DISPATCHER.dispatch(EventType.KeyReleaseEvent, **event_data)
        if propagate_event is not None and propagate_event is False:
            return

    def on_key_press(
        self,
        symbol: int,
        modifiers: int
    ) -> None:
        try:
            char = chr(symbol)
        except OverflowError:
            log.warning("The value of the pressed key is too large.")
            return

        event_data = {"symbol": symbol, "modifiers": modifiers}
        propagate_event = EVENT_DISPATCHER.dispatch(EventType.KeyPressEvent, **event_data)
        if propagate_event is not None and propagate_event is False:
            return

        if char == manim_config.key_bindings.reset:
            if sys.platform == "emscripten":
                import asyncio
                task = getattr(self, "_browser_animation_task", None)
                if task is not None and not task.done():
                    task.cancel()
                self._browser_animation_task = asyncio.create_task(
                    self.play_async(
                        self.camera.frame.animate.to_default_state(),
                        register=False,
                    )
                )
            else:
                self.play(self.camera.frame.animate.to_default_state(), register=False)
        elif char == "z" and (modifiers & Mods.CTRL_OR_CMD):
            self.undo()
        elif char == "z" and (modifiers & (Mods.CTRL_OR_CMD | Mods.SHIFT)):
            self.redo()
        # command + q
        elif char == manim_config.key_bindings.quit and (modifiers & Mods.CTRL_OR_CMD):
            self.quit_interaction = True
        # Space or right arrow
        elif char == " " or symbol == Keys.RIGHT:
            self.hold_on_wait = False

    def on_resize(self, width: int, height: int) -> None:
        pass

    def on_show(self) -> None:
        pass

    def on_hide(self) -> None:
        pass

    def on_close(self) -> None:
        pass

    def focus(self) -> None:
        """
        Puts focus on the ManimGL window.
        """
        if not self.window:
            return
        self.window.focus()

    def set_background_color(self, background_color, background_opacity=1) -> None:
        self.camera.background_rgba = list(color_to_rgba(
            background_color, background_opacity
        ))


class SceneState():
    def __init__(self, scene: Scene, ignore: list[Mobject] | None = None):
        self.time = scene.time
        self.num_plays = scene.num_plays
        self.mobjects_to_copies = OrderedDict.fromkeys(scene.mobjects)
        if ignore:
            for mob in ignore:
                self.mobjects_to_copies.pop(mob, None)

        last_m2c = scene.undo_stack[-1].mobjects_to_copies if scene.undo_stack else dict()
        for mob in self.mobjects_to_copies:
            # If it hasn't changed since the last state, just point to the
            # same copy as before
            if mob in last_m2c and last_m2c[mob].looks_identical(mob):
                self.mobjects_to_copies[mob] = last_m2c[mob]
            else:
                self.mobjects_to_copies[mob] = mob.copy()

    def __eq__(self, state: SceneState):
        return all((
            self.time == state.time,
            self.num_plays == state.num_plays,
            self.mobjects_to_copies == state.mobjects_to_copies
        ))

    def mobjects_match(self, state: SceneState):
        return self.mobjects_to_copies == state.mobjects_to_copies

    def n_changes(self, state: SceneState):
        m2c = state.mobjects_to_copies
        return sum(
            1 - int(mob in m2c and mob.looks_identical(m2c[mob]))
            for mob in self.mobjects_to_copies
        )

    def restore_scene(self, scene: Scene):
        scene.time = self.time
        scene.num_plays = self.num_plays
        scene.mobjects = [
            mob.become(mob_copy, match_updaters=True)
            for mob, mob_copy in self.mobjects_to_copies.items()
        ]


class EndScene(Exception):
    pass


class ThreeDScene(Scene):
    samples = 4
    default_frame_orientation = (-30, 70)
    always_depth_test = True

    def add(self, *mobjects: Mobject, set_depth_test: bool = True, perp_stroke: bool = True):
        for mob in mobjects:
            # Asked of each member of the family in turn, rather than of what holds them.
            # A group has a say of its own on being fixed in frame, which is nothing to do
            # with what it holds, and animations wrap what they are given in a fresh one,
            # so text fixed in frame would otherwise find itself depth tested for the
            # length of a FadeTransform, and vanish behind whatever it was written over.
            if set_depth_test and self.always_depth_test:
                for sm in mob.get_family():
                    if not sm.is_fixed_in_frame():
                        sm.apply_depth_test(recurse=False)
            if isinstance(mob, VMobject) and mob.has_stroke() and perp_stroke:
                mob.set_flat_stroke(False)
        super().add(*mobjects)