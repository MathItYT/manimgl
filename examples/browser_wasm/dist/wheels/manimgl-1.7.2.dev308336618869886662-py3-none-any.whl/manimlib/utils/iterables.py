from __future__ import annotations

from colour import Color

import numpy as np
import random

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Callable, Iterable, Sequence, TypeVar

    T = TypeVar("T")
    S = TypeVar("S")


def remove_list_redundancies(lst: Sequence[T]) -> list[T]:
    """
    Remove duplicate elements while preserving order.
    Keeps the last occurrence of each element
    """
    return list(reversed(dict.fromkeys(reversed(lst))))


def list_update(l1: Iterable[T], l2: Iterable[T]) -> list[T]:
    """
    Used instead of list(set(l1).update(l2)) to maintain order,
    making sure duplicates are removed from l1, not l2.
    """
    return remove_list_redundancies([*l1, *l2])


def list_difference_update(l1: Iterable[T], l2: Iterable[T]) -> list[T]:
    return [e for e in l1 if e not in l2]


def adjacent_n_tuples(objects: Sequence[T], n: int) -> zip[tuple[T, ...]]:
    return zip(*[
        [*objects[k:], *objects[:k]]
        for k in range(n)
    ])


def adjacent_pairs(objects: Sequence[T]) -> zip[tuple[T, T]]:
    return adjacent_n_tuples(objects, 2)


def batch_by_property(
    items: Iterable[T],
    property_func: Callable[[T], S]
) -> list[tuple[T, S]]:
    """
    Takes in a list, and returns a list of tuples, (batch, prop)
    such that all items in a batch have the same output when
    put into property_func, and such that chaining all these
    batches together would give the original list (i.e. order is
    preserved)
    """
    batch_prop_pairs = []
    curr_batch = []
    curr_prop = None
    for item in items:
        prop = property_func(item)
        if prop != curr_prop:
            # Add current batch
            if len(curr_batch) > 0:
                batch_prop_pairs.append((curr_batch, curr_prop))
            # Redefine curr
            curr_prop = prop
            curr_batch = [item]
        else:
            curr_batch.append(item)
    if len(curr_batch) > 0:
        batch_prop_pairs.append((curr_batch, curr_prop))
    return batch_prop_pairs


def batch_by_comparison(
    items: Iterable[T],
    comparison: Callable[[T, T], bool]
) -> List[List[T]]:
    """
    Runs of consecutive items, each item joining the one before it wherever the comparison
    says the two belong together, and beginning a run of its own wherever it does not.

    The comparison is handed the last item of the run so far and the one being placed, in
    that order, and is asked about neighbors only: a run is however far that reaches, not a
    set of items all alike.
    """
    batches = []
    for item in items:
        if batches and comparison(batches[-1][-1], item):
            batches[-1].append(item)
        else:
            batches.append([item])
    return batches


def listify(obj: object) -> list:
    if isinstance(obj, str):
        return [obj]
    try:
        return list(obj)
    except TypeError:
        return [obj]


def shuffled(iterable: Iterable) -> list:
    as_list = list(iterable)
    random.shuffle(as_list)
    return as_list


def resize_array(nparray: np.ndarray, length: int) -> np.ndarray:
    if len(nparray) == length:
        return nparray
    return np.resize(nparray, (length, *nparray.shape[1:]))


def resize_preserving_order(nparray: np.ndarray, length: int) -> np.ndarray:
    if len(nparray) == 0:
        return np.resize(nparray, length)
    if len(nparray) == length:
        return nparray
    indices = np.arange(length) * len(nparray) // length
    return nparray[indices]


def resize_with_interpolation(nparray: np.ndarray, length: int) -> np.ndarray:
    if len(nparray) == length:
        return nparray
    if len(nparray) == 1 or array_is_constant(nparray):
        return nparray[:1].repeat(length, axis=0)
    if length == 0:
        return np.zeros((0, *nparray.shape[1:]))
    cont_indices = np.linspace(0, len(nparray) - 1, length)
    lh = cont_indices.astype(int)
    rh = np.minimum(lh + 1, len(nparray) - 1)
    a = (cont_indices - lh).reshape((length,) + (1,) * (nparray.ndim - 1))
    return (1.0 - a) * nparray[lh] + a * nparray[rh]


def make_even(
    iterable_1: Sequence[T],
    iterable_2: Sequence[S]
) -> tuple[Sequence[T], Sequence[S]]:
    len1 = len(iterable_1)
    len2 = len(iterable_2)
    if len1 == len2:
        return iterable_1, iterable_2
    new_len = max(len1, len2)
    return (
        [iterable_1[(n * len1) // new_len] for n in range(new_len)],
        [iterable_2[(n * len2) // new_len] for n in range(new_len)]
    )


def arrays_match(arr1: np.ndarray, arr2: np.ndarray) -> bool:
    return np.array_equal(arr1, arr2)


def array_is_constant(arr: np.ndarray) -> bool:
    if len(arr) == 0:
        return False
    if len(arr) == 1:
        return True
    return bool((arr == arr[0]).all())


def index_within_group(counts: np.ndarray) -> np.ndarray:
    """
    Where each member of a run of groups sits within its own group, given how many members
    each holds, e.g. [3, 2] -> [0, 1, 2, 0, 1]
    """
    return np.arange(counts.sum()) - np.repeat(np.cumsum(counts) - counts, counts)


def keep_larger(start: np.ndarray, end: np.ndarray, alpha: float) -> np.ndarray:
    """
    Takes in both rather than blending between them, for a field which counts something and
    would mean nothing partway, see Mobject.structural_data_keys.

    Shaped like a path function, alpha and all, so that everything interpolate is handed to
    write over a field with can be called the one way.
    """
    return np.maximum(start, end)


def cartesian_product(*arrays: np.ndarray):
    """
    Copied from https://stackoverflow.com/a/11146645
    """
    la = len(arrays)
    dtype = np.result_type(*arrays)
    arr = np.empty([len(a) for a in arrays] + [la], dtype=dtype)
    for i, a in enumerate(np.ix_(*arrays)):
        arr[..., i] = a
    return arr.reshape(-1, la)


def hash_obj(obj: object) -> int:
    if isinstance(obj, dict):
        return hash(tuple(sorted([
            (hash_obj(k), hash_obj(v)) for k, v in obj.items()
        ])))

    if isinstance(obj, set):
        return hash(tuple(sorted(hash_obj(e) for e in obj)))

    if isinstance(obj, (tuple, list)):
        return hash(tuple(hash_obj(e) for e in obj))

    if isinstance(obj, Color):
        return hash(obj.get_rgb())

    return hash(obj)
