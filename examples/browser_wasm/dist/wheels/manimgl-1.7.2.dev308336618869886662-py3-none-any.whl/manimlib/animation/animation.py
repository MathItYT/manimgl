from __future__ import annotations

from copy import deepcopy
import inspect

from manimlib.mobject.mobject import _AnimationBuilder
from manimlib.mobject.mobject import Mobject
from manimlib.utils.iterables import remove_list_redundancies
from manimlib.utils.rate_functions import smooth
from manimlib.utils.simple_functions import clip

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Callable

    from manimlib.scene.scene import Scene


DEFAULT_ANIMATION_RUN_TIME = 1.0
DEFAULT_ANIMATION_LAG_RATIO = 0


class Animation(object):
    def __init__(
        self,
        mobject: Mobject,
        run_time: float = DEFAULT_ANIMATION_RUN_TIME,
        # Tuple of times, between which the animation will run
        time_span: tuple[float, float] | None = None,
        # If 0, the animation is applied to all submobjects at the same time
        # If 1, it is applied to each successively.
        # If 0 < lag_ratio < 1, its applied to each with lagged start times
        lag_ratio: float = DEFAULT_ANIMATION_LAG_RATIO,
        rate_func: Callable[[float], float] = smooth,
        name: str = "",
        # Does this animation add or remove a mobject from the screen
        remover: bool = False,
        # What to enter into the update function upon completion
        final_alpha_value: float = 1.0,
        # If set to True, the mobject itself will have its internal updaters called,
        # but the start or target mobjects would not be suspended. To completely suspend
        # updating, call mobject.suspend_updating() before the animation
        suspend_mobject_updating: bool = False,
    ):
        self._validate_input_type(mobject)
        self.mobject = mobject
        self.run_time = run_time
        self.time_span = time_span
        self.rate_func = rate_func
        self.name = name or self.__class__.__name__ + str(self.mobject)
        self.remover = remover
        self.final_alpha_value = final_alpha_value
        self.lag_ratio = lag_ratio
        self.suspend_mobject_updating = suspend_mobject_updating

    def _validate_input_type(self, mobject: Mobject) -> None:
        if not isinstance(mobject, Mobject):
            raise TypeError("Animation only works for Mobjects.")

    def __str__(self) -> str:
        return self.name

    @classmethod
    async def create(cls, *args, **kwargs):
        """Asynchronously construct an animation and any awaited arguments."""
        args = await resolve_async(args)
        kwargs = await resolve_async(kwargs)
        return cls(*args, **kwargs)

    def begin(self) -> None:
        # This is called right as an animation is being
        # played.  As much initialization as possible,
        # especially any mobject copying, should live in
        # this method
        if self.time_span is not None:
            start, end = self.time_span
            self.run_time = max(end, self.run_time)
        self.mobject.set_animating_status(True)
        self.starting_mobject = self.create_starting_mobject()
        if self.suspend_mobject_updating:
            self.mobject_was_updating = not self.mobject.updating_suspended
            self.mobject.suspend_updating()
        self.families = list(self.get_all_families_zipped())
        self.prepare_interpolation()
        self.interpolate(0)

    def prepare_interpolation(self) -> None:
        """
        Whatever holds of the two ends for the whole of the animation, settled here rather
        than found again in every blend, see Mobject.prepare_interpolation.

        One which changes its ends after they have been made says so by calling this again,
        see FadeTransform.
        """
        ends = self.get_interpolation_ends()
        if ends is not None:
            self.mobject.prepare_interpolation(*ends)

    def get_interpolation_ends(self) -> tuple[Mobject, Mobject] | None:
        """
        The two states every blend this animation makes runs between, in the order it blends
        them, or none where it makes no such blend and so has nothing to settle in advance.

        Saying so is the animation's to do rather than something read off the mobjects it
        gathers: those same three may be two ends with the mobject between them, or a mobject
        and two others put to some other use entirely.
        """
        return None

    def finish(self) -> None:
        self.interpolate(self.final_alpha_value)
        self.mobject.turn_off_interpolation_skip()
        self.mobject.set_animating_status(False)
        if self.suspend_mobject_updating and self.mobject_was_updating:
            self.mobject.resume_updating()

    def clean_up_from_scene(self, scene: Scene) -> None:
        if self.is_remover():
            scene.remove(self.mobject)

    def create_starting_mobject(self) -> Mobject:
        # Keep track of where the mobject starts
        return self.mobject.copy()

    def get_all_mobjects(self) -> tuple[Mobject, Mobject]:
        """
        Ordering must match the ording of arguments to interpolate_submobject
        """
        return self.mobject, self.starting_mobject

    def get_all_families_zipped(self) -> zip[tuple[Mobject]]:
        return zip(*[
            mob.get_family()
            for mob in self.get_all_mobjects()
        ])

    def update_reference_mobjects(self, dt: float, frame_rate: float | None = None) -> None:
        """
        Updates things like starting_mobject, and (for
        Transforms) target_mobject.
        """
        for mob in self.get_reference_mobjects():
            mob.update(dt, frame_rate=frame_rate)

    def get_reference_mobjects(self) -> list[Mobject]:
        """
        Returns mobjects the Animation tracks other than
        self.mobject, e.g. the start and end points of
        interpolation.
        """
        # Remove redundancies for cases like Transform where target and target_copy
        # are the same, which happens when the already align.
        return remove_list_redundancies([
            mob for mob in self.get_all_mobjects()
            if mob is not self.mobject
        ])

    def copy(self):
        return deepcopy(self)

    def update_rate_info(
        self,
        run_time: float | None = None,
        rate_func: Callable[[float], float] | None = None,
        lag_ratio: float | None = None,
    ):
        self.run_time = run_time or self.run_time
        self.rate_func = rate_func or self.rate_func
        self.lag_ratio = lag_ratio or self.lag_ratio
        return self

    # Methods for interpolation, the mean of an Animation
    def interpolate(self, alpha: float) -> None:
        self.interpolate_mobject(alpha)

    def update(self, alpha: float) -> None:
        """
        This method shouldn't exist, but it's here to
        keep many old scenes from breaking
        """
        self.interpolate(alpha)

    def time_spanned_alpha(self, alpha: float) -> float:
        if self.time_span is not None:
            start, end = self.time_span
            return clip(alpha * self.run_time - start, 0, end - start) / (end - start)
        return alpha

    def interpolate_mobject(self, alpha: float) -> None:
        t_alpha = self.time_spanned_alpha(alpha)
        n_families = len(self.families)
        if self.lag_ratio == 0:
            sub_alpha = self.rate_func(clip(t_alpha, 0, 1))
            for mobs in self.families:
                self.interpolate_submobject(*mobs, sub_alpha)
        else:
            for i, mobs in enumerate(self.families):
                sub_alpha = self.get_sub_alpha(t_alpha, i, n_families)
                self.interpolate_submobject(*mobs, sub_alpha)

    def interpolate_submobject(
        self,
        submobject: Mobject,
        starting_submobject: Mobject,
        alpha: float
    ):
        # Typically ipmlemented by subclass
        pass

    def get_sub_alpha(
        self,
        alpha: float,
        index: int,
        num_submobjects: int
    ) -> float:
        lag_ratio = self.lag_ratio
        if lag_ratio == 0:
            return self.rate_func(clip(alpha, 0, 1))
        full_length = (num_submobjects - 1) * lag_ratio + 1
        value = alpha * full_length
        lower = index * lag_ratio
        raw_sub_alpha = clip((value - lower), 0, 1)
        return self.rate_func(raw_sub_alpha)

    # Getters and setters
    def set_run_time(self, run_time: float):
        self.run_time = run_time
        return self

    def get_run_time(self) -> float:
        if self.time_span:
            return max(self.run_time, self.time_span[1])
        return self.run_time

    def set_rate_func(self, rate_func: Callable[[float], float]):
        self.rate_func = rate_func
        return self

    def get_rate_func(self) -> Callable[[float], float]:
        return self.rate_func

    def set_name(self, name: str):
        self.name = name
        return self

    def is_remover(self) -> bool:
        return self.remover


async def resolve_async(value):
    """Recursively await async scene objects before constructing animations."""
    if inspect.isawaitable(value):
        return await resolve_async(await value)
    if isinstance(value, tuple):
        return tuple([await resolve_async(item) for item in value])
    if isinstance(value, list):
        return [await resolve_async(item) for item in value]
    if isinstance(value, dict):
        return {
            key: await resolve_async(item)
            for key, item in value.items()
        }
    return value


def prepare_animation(anim: Animation | _AnimationBuilder):
    if isinstance(anim, _AnimationBuilder):
        return anim.build()

    if isinstance(anim, Animation):
        return anim

    raise TypeError(f"Object {anim} cannot be converted to an animation")


async def prepare_animation_async(anim):
    anim = await resolve_async(anim)
    return prepare_animation(anim)
