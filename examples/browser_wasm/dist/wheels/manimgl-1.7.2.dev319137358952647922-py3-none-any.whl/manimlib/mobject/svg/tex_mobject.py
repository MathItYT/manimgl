from __future__ import annotations

import re
import sys

from functools import lru_cache

from manimlib.config import manim_config
from manimlib.mobject.svg.string_mobject import StringMobject
from manimlib.mobject.svg.svg_mobject import SVGMobject, get_svg_content_height
from manimlib.mobject.types.vectorized_mobject import VGroup
from manimlib.mobject.types.vectorized_mobject import VMobject
from manimlib.utils.color import color_to_hex
from manimlib.utils.color import hex_to_int
from manimlib.utils.typst_file_writing import typst_to_svg
from manimlib.utils.tex import num_tex_symbols, parse_tex_submob_map
from manimlib.logger import log

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from manimlib.typing import ManimColor, Span, Selector, Self


@lru_cache(maxsize=8)
def get_tex_mob_scale_factor(text_mode: bool = False, font: str = "New Computer Modern") -> float:
    # Render a reference "0" and calibrate so that font_size_for_unit_height
    # gives a height of 1 manim unit.
    font_size_for_unit_height = manim_config.tex.font_size_for_unit_height
    svg_string = typst_to_svg(Tex._make_mitex_source("0", text_mode=text_mode, font=font))
    svg_height = get_svg_content_height(svg_string)
    return 1.0 / (font_size_for_unit_height * svg_height)


class Tex(StringMobject):
    tex_environment: str = "align*"

    def __init__(
        self,
        *tex_strings: str,
        font_size: int = 48,
        font: str = "New Computer Modern",
        alignment: str = R"\centering",
        template: str = "",
        additional_preamble: str = "",
        tex_to_color_map: dict = dict(),
        t2c: dict = dict(),
        isolate: Selector = [],
        use_labelled_svg: bool = True,
        **kwargs
    ):
        # Combine multi-string arg, but mark them to isolate
        if len(tex_strings) > 1:
            if isinstance(isolate, (str, re.Pattern, tuple)):
                isolate = [isolate]
            isolate = [*isolate, *tex_strings]

        tex_string = (" ".join(tex_strings)).strip()

        # Prevent from passing an empty string.
        if not tex_string.strip():
            tex_string = R"\\"

        self.tex_string = tex_string
        self.font = font
        self.alignment = alignment
        self.template = template
        self.additional_preamble = additional_preamble
        self.tex_to_color_map = dict(**t2c, **tex_to_color_map)

        text_mode = not bool(self.tex_environment)

        super().__init__(
            tex_string,
            use_labelled_svg=use_labelled_svg,
            isolate=isolate,
            height=None,
            stroke_width=None,
            **kwargs
        )

        self.set_color_by_tex_to_color_map(self.tex_to_color_map)
        # The browser renders TeX through MiTeX inside typst-wasm. Its SVG is
        # asynchronous, so browser scaling is applied by create() after rendering.
        if sys.platform != "emscripten":
            scale_factor = get_tex_mob_scale_factor(text_mode=text_mode, font=self.font) * font_size
            self.scale(scale_factor)
            self.scale_stroke_widths(scale_factor)

        self.font_size = font_size  # Important for this to go after the scale call

    @classmethod
    def create(cls, *tex_strings: str, **kwargs):
        """Create Tex/TexText, using MiTeX."""
        if sys.platform != "emscripten":
            return cls(*tex_strings, **kwargs)
        return cls._create_browser(*tex_strings, **kwargs)

    @staticmethod
    def _make_mitex_source(
        content: str,
        *,
        text_mode: bool = False,
        font: str = "New Computer Modern",
        is_labelled: bool = False,
    ) -> str:
        fill_col = "#000000" if is_labelled else "#ffffff"
        font_rule = f'#set text(font: "{font}")\n' if font else ""
        doc_head = (
            f'#set page(width: auto, height: auto, margin: 0pt, fill: none)\n'
            f'#set text(fill: rgb("{fill_col}"), size: 10pt, ligatures: false)\n'
            f'{font_rule}'
            f'#show math.equation: set text(ligatures: false)\n'
            f'#set line(stroke: rgb("{fill_col}"))\n'
            f'#let _mc(c, it) = if c != "" {{ text(fill: rgb(c), it) }} else {{ it }}\n'
        ).strip()

        delimiter = "`"
        command = "mitext" if text_mode else "mitex"
        return f"#import \"@preview/mitex:0.2.7\": *\n{doc_head}\n" + f'#{command}({delimiter}\n{content}\n{delimiter})\n'

    @classmethod
    async def _create_browser(cls, *tex_strings: str, **kwargs):
        from manimlib.utils.browser_typst import typst_to_svg_async

        use_labelled_svg = kwargs.get("use_labelled_svg", True)
        font_size = kwargs.get("font_size", 48)
        text_mode = not bool(cls.tex_environment)

        # Build a probe with an empty SVG. This preserves Tex's native parsing,
        # isolation spans, color-label insertion, and options without invoking
        # the native LaTeX executable on the browser.
        probe_kwargs = dict(kwargs)
        for private_key in ("_svg_override", "_labelled_svg_override"):
            probe_kwargs.pop(private_key, None)
        probe_kwargs["use_labelled_svg"] = True
        probe_kwargs["_svg_override"] = (
            '<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1" '
            'viewBox="0 0 1 1"/>'
        )
        probe = cls(*tex_strings, **probe_kwargs)

        async def render(is_labelled: bool) -> str:
            content = probe.get_content(is_labelled=is_labelled)
            # \centering is a layout command rather than equation content and
            # is not needed in Typst's auto-sized SVG page.
            if probe.alignment:
                content = content.replace(probe.alignment, "")
            if probe.additional_preamble:
                content = probe.additional_preamble + "\n" + content
            svg = await typst_to_svg_async(
                cls._make_mitex_source(
                    content,
                    text_mode=text_mode,
                    font=probe.font,
                    is_labelled=is_labelled,
                )
            )
            return svg

        svg = await render(is_labelled=use_labelled_svg)
        labelled_svg = None if use_labelled_svg else await render(is_labelled=True)

        final_kwargs = dict(kwargs)
        final_kwargs.pop("_svg_override", None)
        final_kwargs.pop("_labelled_svg_override", None)
        final_kwargs["_svg_override"] = svg
        final_kwargs["use_labelled_svg"] = use_labelled_svg
        if labelled_svg is not None:
            final_kwargs["_labelled_svg_override"] = labelled_svg

        obj = cls(*tex_strings, **final_kwargs)

        # Calibrate independently for math and text-mode MiTeX output.
        scale_key = (text_mode, cls.tex_environment)
        scale_cache = getattr(Tex, "_browser_scale_cache", None)
        if scale_cache is None:
            scale_cache = {}
            Tex._browser_scale_cache = scale_cache
        if scale_key not in scale_cache:
            reference_svg = await typst_to_svg_async(
                cls._make_mitex_source("0", text_mode=text_mode, font=probe.font)
            )
            svg_height = get_svg_content_height(reference_svg)
            scale_cache[scale_key] = (
                1.0 / (manim_config.tex.font_size_for_unit_height * svg_height)
            )
        obj.scale(scale_cache[scale_key] * font_size)
        obj.scale_stroke_widths(scale_cache[scale_key] * font_size)
        # Native Tex scales before assigning font_size, so retain that behavior.
        obj.font_size = font_size
        return obj

    def get_svg_string_by_content(self, content: str) -> str:
        text_mode = not bool(self.tex_environment)
        is_labelled = "\\color[RGB]{" in content
        if self.alignment and self.alignment in content:
            content = content.replace(self.alignment, "")
        if self.additional_preamble:
            content = self.additional_preamble + "\n" + content
        mitex_src = self._make_mitex_source(
            content,
            text_mode=text_mode,
            font=getattr(self, "font", "New Computer Modern"),
            is_labelled=is_labelled,
        )
        return typst_to_svg(mitex_src)

    def _handle_scale_side_effects(self, scale_factor: float) -> Self:
        if hasattr(self, "font_size"):
            self.font_size *= scale_factor
        return self

    # Parsing

    @staticmethod
    def get_command_matches(string: str) -> list[re.Match]:
        # Lump together adjacent brace pairs
        pattern = re.compile(r"""
            (?P<command>\\(?:[a-zA-Z]+|.))
            |(?P<open>{+)
            |(?P<close>}+)
        """, flags=re.X | re.S)
        result = []
        open_stack = []
        for match_obj in pattern.finditer(string):
            if match_obj.group("open"):
                open_stack.append((match_obj.span(), len(result)))
            elif match_obj.group("close"):
                close_start, close_end = match_obj.span()
                while True:
                    if not open_stack:
                        raise ValueError("Missing '{' inserted")
                    (open_start, open_end), index = open_stack.pop()
                    n = min(open_end - open_start, close_end - close_start)
                    result.insert(index, pattern.fullmatch(
                        string, pos=open_end - n, endpos=open_end
                    ))
                    result.append(pattern.fullmatch(
                        string, pos=close_start, endpos=close_start + n
                    ))
                    close_start += n
                    if close_start < close_end:
                        continue
                    open_end -= n
                    if open_start < open_end:
                        open_stack.append(((open_start, open_end), index))
                    break
            else:
                result.append(match_obj)
        if open_stack:
            raise ValueError("Missing '}' inserted")
        return result

    @staticmethod
    def get_command_flag(match_obj: re.Match) -> int:
        if match_obj.group("open"):
            return 1
        if match_obj.group("close"):
            return -1
        return 0

    @staticmethod
    def replace_for_content(match_obj: re.Match) -> str:
        return match_obj.group()

    @staticmethod
    def replace_for_matching(match_obj: re.Match) -> str:
        if match_obj.group("command"):
            return match_obj.group()
        return ""

    @staticmethod
    def get_attr_dict_from_command_pair(
        open_command: re.Match, close_command: re.Match
    ) -> dict[str, str] | None:
        if len(open_command.group()) >= 2:
            return {}
        return None

    def get_configured_items(self) -> list[tuple[Span, dict[str, str]]]:
        return [
            (span, {})
            for selector in self.tex_to_color_map
            for span in self.find_spans_by_selector(selector)
        ]

    @staticmethod
    def get_color_command(rgb_hex: str) -> str:
        rgb = hex_to_int(rgb_hex)
        rg, b = divmod(rgb, 256)
        r, g = divmod(rg, 256)
        return f"\\color[RGB]{{{r}, {g}, {b}}}"

    @staticmethod
    def get_command_string(
        attr_dict: dict[str, str], is_end: bool, label_hex: str | None
    ) -> str:
        if label_hex is None:
            return ""
        if is_end:
            return "}}"
        return "{{" + Tex.get_color_command(label_hex)

    def get_content_prefix_and_suffix(
        self, is_labelled: bool
    ) -> tuple[str, str]:
        prefix_lines = []
        suffix_lines = []
        if not is_labelled:
            prefix_lines.append(self.get_color_command(
                color_to_hex(self.base_color)
            ))
        if self.alignment:
            prefix_lines.append(self.alignment)
        if self.tex_environment:
            prefix_lines.append(f"\\begin{{{self.tex_environment}}}")
            suffix_lines.append(f"\\end{{{self.tex_environment}}}")
        return (
            "".join([line + "\n" for line in prefix_lines]),
            "".join(["\n" + line for line in suffix_lines])
        )

    # Method alias

    def get_parts_by_tex(self, selector: Selector) -> VGroup:
        return self.select_parts(selector)

    def get_part_by_tex(self, selector: Selector, index: int = 0) -> VMobject:
        return self.select_part(selector, index)

    def set_color_by_tex(self, selector: Selector, color: ManimColor):
        return self.set_parts_color(selector, color)

    def set_color_by_tex_to_color_map(
        self, color_map: dict[Selector, ManimColor]
    ):
        return self.set_parts_color_by_dict(color_map)

    def get_tex(self) -> str:
        return self.get_string()

    # Specific to Tex
    def _get_char_to_submob_indices(self) -> list[list[int]]:
        if not hasattr(self, "_char_to_submob_map"):
            _, self._token_spans, self._char_to_submob_map = parse_tex_submob_map(self.string)
        return self._char_to_submob_map

    def get_token_submob_map(self) -> list[tuple[Span, list[int], str]]:
        if not hasattr(self, "_token_spans"):
            _, self._token_spans, self._char_to_submob_map = parse_tex_submob_map(self.string)
        return sorted(
            [(span, idxs, "/" if tok == "frac_bar" else tok) for span, idxs, tok in self._token_spans if idxs],
            key=lambda item: item[0][0]
        )

    def get_submob_indices_for_span(self, span: Span) -> list[int]:
        mapping = self._get_char_to_submob_indices()
        indices = []
        for c in range(span[0], min(span[1], len(mapping))):
            for idx in mapping[c]:
                if idx not in indices and idx < len(self.submobjects):
                    indices.append(idx)
        return sorted(indices)

    def select_unisolated_substring(self, pattern: str | re.Pattern) -> VGroup:
        spans = self.find_spans_by_selector(pattern)
        indices_list = [self.get_submob_indices_for_span(span) for span in spans]
        indices_list = [idx for idx in indices_list if idx]
        return self.build_parts_from_indices_lists(indices_list)

    def get_submob_indices_list_by_span(self, arbitrary_span: Span) -> list[int]:
        result = super().get_submob_indices_list_by_span(arbitrary_span)
        if not result:
            return self.get_submob_indices_for_span(arbitrary_span)
        return result

    def substr_to_path_count(self, substr: str) -> int:
        return num_tex_symbols(substr)

    def get_symbol_substrings(self):
        pattern = "|".join((
            # Tex commands
            r"\\[a-zA-Z]+",
            # And most single characters, with these exceptions
            r"[^\^\{\}\s\_\$\\\&]",
        ))
        return re.findall(pattern, self.string)

    def make_number_changeable(
        self,
        value: float | int | str,
        index: int = 0,
        replace_all: bool = False,
        **config,
    ) -> VMobject:
        substr = str(value)
        parts = self.select_parts(substr)
        if len(parts) == 0:
            log.warning(f"{value} not found in Tex.make_number_changeable call")
            return VMobject()
        if index > len(parts) - 1:
            log.warning(f"Requested {index}th occurance of {value}, but only {len(parts)} exist")
            return VMobject()
        if not replace_all:
            parts = [parts[index]]

        from manimlib.mobject.numbers import DecimalNumber

        decimal_mobs = []
        for part in parts:
            if "num_decimal_places" not in config:
                ndp = len(substr.split(".")[1]) if "." in substr else 0
                config["num_decimal_places"] = ndp
            decimal_mob = DecimalNumber(float(value), **config)
            decimal_mob.replace(part)
            decimal_mob.match_style(part)
            if len(part) > 1:
                self.remove(*part[1:])
            self.replace_submobject(self.submobjects.index(part[0]), decimal_mob)
            decimal_mobs.append(decimal_mob)

            # Replace substr with something that looks like a tex command. This
            # is to ensure Tex.substr_to_path_count counts it correctly.
            self.string = self.string.replace(substr, R"\decimalmob", 1)

        if replace_all:
            return VGroup(*decimal_mobs)
        return decimal_mobs[index]


class TexText(Tex):
    tex_environment: str = ""
