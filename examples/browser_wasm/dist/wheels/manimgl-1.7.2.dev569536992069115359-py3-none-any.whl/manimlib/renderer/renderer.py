from __future__ import annotations

import wgpu
import numpy as np

from manimlib.renderer.gpu import Gpu, RenderPass
from manimlib.renderer.material import Material
from manimlib.renderer.post_process import MobjectPostProcessor
from manimlib.utils.iterables import batch_by_comparison
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Any, Callable, Iterable
    from manimlib.mobject.mobject import Mobject
    from manimlib.renderer.drawing import Drawing
    from manimlib.renderer.shared_buffer import SharedBuffer


FRAMES_BEFORE_BUNDLING = 2


class Bundling(object):
    def __init__(self, allowed: bool = True):
        self.allowed = allowed
        self.bundle: Any = None
        self.settled = 0
        self.stale = True

    def invalidate(self) -> None:
        self.stale = True

    def take(self, make: Callable[[], Any]) -> Any:
        if self.stale:
            self.stale = False
            self.settled = 0
            self.bundle = None
        else:
            self.settled += 1
            if self.bundle is None and self.allowed and self.settled >= FRAMES_BEFORE_BUNDLING:
                self.bundle = make()
        return self.bundle


class Renderer(object):
    def __init__(self, gpu: Gpu, bundle: bool = True, together: bool = True):
        self.gpu = gpu
        self.camera: Any = None
        self.post_processor = MobjectPostProcessor(self.gpu)
        self.post_processor.renderer = self
        self.may_merge = together
        self.bundling = Bundling(allowed=bundle)
        self.materials: dict[tuple, Material] = dict()
        self.drawings: dict[Mobject, Drawing] = dict()
        self.offscreen_drawings: dict[Mobject, Drawing] = dict()
        self.offscreen_leaders: dict[Mobject, list[Drawing]] = dict()
        self.drawn: list[Drawing] = []
        self.leaders: list[Drawing] = []
        self.run_lengths: tuple = ()
        self.samples = gpu.samples

    def get_vfx_group(self, mob: Mobject) -> Mobject | None:
        from manimlib.camera.camera_frame import CameraFrame
        group = getattr(mob, "_vfx_group", None)
        if group is not None and not isinstance(group, CameraFrame) and getattr(group, "has_vfx", lambda: False)():
            return group
        local = getattr(mob, "_vfx_local", None)
        if local is not None and not isinstance(local, CameraFrame) and getattr(local, "has_vfx", lambda: False)():
            return local
        if not isinstance(mob, CameraFrame) and getattr(mob, "has_vfx", lambda: False)():
            return mob
        return None

    def get_frame_vfx_list(self, mobjects: Iterable[Mobject] | None = None) -> list[Any]:
        effects: list[Any] = []
        seen_ids: set[int] = set()
        cam = self.camera
        if cam is not None:
            for eff in getattr(cam, "get_vfx_list", lambda: getattr(cam, "_vfx_effects", []))():
                if id(eff) not in seen_ids:
                    seen_ids.add(id(eff))
                    effects.append(eff)
            frame = getattr(cam, "frame", None)
            if frame is not None:
                for eff in getattr(frame, "get_vfx_list", lambda: [])():
                    if id(eff) not in seen_ids:
                        seen_ids.add(id(eff))
                        effects.append(eff)
        if mobjects is not None:
            from manimlib.camera.camera_frame import CameraFrame
            for mob in mobjects:
                if isinstance(mob, CameraFrame):
                    for eff in mob.get_vfx_list():
                        if id(eff) not in seen_ids:
                            seen_ids.add(id(eff))
                            effects.append(eff)
        return effects

    def optimize_leaders_dag(self, leaders: list[Drawing]) -> list[Drawing]:
        """Reordena líderes mediante un DAG de oclusión para agrupar pases de VFX
        sin alterar el orden visual (respetando solapamientos 2D y z_index).
        """
        n = len(leaders)
        if n <= 1:
            return leaders

        # Solo aplicamos en 2D para no alterar la profundidad Back-to-Front en 3D
        frame = getattr(self.camera, "frame", None)
        if frame is not None:
            phi = getattr(frame, "get_phi", lambda: 0.0)()
            theta = getattr(frame, "get_theta", lambda: 0.0)()
            if abs(phi) > 1e-3 or abs(theta) > 1e-3:
                return leaders

        groups = [self.get_vfx_group(ldr.mobject) for ldr in leaders]
        unique_groups = {g for g in groups if g is not None}
        if not unique_groups:
            return leaders

        if frame is not None:
            cam_c = frame.get_center()
            cam_cx, cam_cy = float(cam_c[0]), float(cam_c[1])
            inv_scale = 1.0 / max(float(frame.get_scale()), 1e-6)
        else:
            cam_cx = cam_cy = 0.0
            inv_scale = 1.0

        bboxes: list[tuple[np.ndarray, np.ndarray] | None] = []
        for idx_ldr, ldr in enumerate(leaders):
            members = ldr.members if ldr.members else (ldr,)
            bmin: np.ndarray | None = None
            bmax: np.ndarray | None = None
            for d in members:
                mob = d.mobject
                if not mob.has_points():
                    continue
                bb = mob.get_bounding_box()
                mmin = bb[0][:2]
                mmax = bb[2][:2]
                is_fixed = (
                    "is_fixed_in_frame" in mob.uniforms.array.dtype.names
                    and bool(mob.uniforms.array["is_fixed_in_frame"][0])
                )
                if frame is not None and not is_fixed:
                    mmin = np.array([(mmin[0] - cam_cx) * inv_scale, (mmin[1] - cam_cy) * inv_scale])
                    mmax = np.array([(mmax[0] - cam_cx) * inv_scale, (mmax[1] - cam_cy) * inv_scale])
                if bmin is None:
                    bmin = mmin.copy()
                    bmax = mmax.copy()
                else:
                    np.minimum(bmin, mmin, out=bmin)
                    np.maximum(bmax, mmax, out=bmax)
            if bmin is not None:
                r_extra = 0.0
                grp = groups[idx_ldr]
                if grp is not None and hasattr(grp, "get_vfx_list"):
                    for eff in grp.get_vfx_list():
                        rad = float(getattr(eff, "radius", 0.0))
                        off = getattr(eff, "offset", None)
                        off_mag = float(np.hypot(off[0], off[1])) if off is not None else 0.0
                        r_extra = max(r_extra, (rad + off_mag) * 0.015)
                bboxes.append((bmin - r_extra, bmax + r_extra))
            else:
                bboxes.append(None)

        in_degree = [0] * n
        adj: list[list[int]] = [[] for _ in range(n)]

        for i in range(n):
            bi = bboxes[i]
            zi = leaders[i].mobject.z_index
            for j in range(i + 1, n):
                zj = leaders[j].mobject.z_index
                bj = bboxes[j]
                overlaps = (
                    bi is not None and bj is not None
                    and not (bi[1][0] < bj[0][0] or bi[0][0] > bj[1][0]
                             or bi[1][1] < bj[0][1] or bi[0][1] > bj[1][1])
                )
                if (zj > zi) or (zj == zi and overlaps):
                    adj[i].append(j)
                    in_degree[j] += 1

        ready = [i for i in range(n) if in_degree[i] == 0]
        ordered: list[Drawing] = []
        current_group: Mobject | None = None

        while ready:
            candidate_idx: int | None = None
            if current_group is not None:
                for idx in ready:
                    if groups[idx] is current_group:
                        candidate_idx = idx
                        break

            if candidate_idx is None:
                candidate_idx = min(ready)
                current_group = groups[candidate_idx]

            ready.remove(candidate_idx)
            ordered.append(leaders[candidate_idx])

            for succ in adj[candidate_idx]:
                in_degree[succ] -= 1
                if in_degree[succ] == 0:
                    ready.append(succ)

        return ordered

    def _prepare_offscreen_mobject(
        self,
        mobject: Mobject,
        held: dict[Mobject, Drawing],
    ) -> list[Drawing]:
        mob_drawings: list[Drawing] = []
        for sm in mobject.get_family():
            drawing_class = sm.drawing_class
            if len(sm.data) == 0 or not drawing_class.draws(sm):
                continue
            drawing = held.get(sm)
            if drawing is None or drawing.replacements is not sm.shader_code_replacements:
                drawing = drawing_class(self.material_for(sm, drawing_class), sm)
            self.offscreen_drawings[sm] = drawing
            drawing.write_uniforms()
            drawing.realize_textures()
            mob_drawings.append(drawing)

        if not mob_drawings:
            return []

        if not self.may_merge or len(mob_drawings) == 1:
            for d in mob_drawings:
                d.members = None
            leaders = list(mob_drawings)
        else:
            self.compare_uniforms(mob_drawings)
            runs = batch_by_comparison(
                mob_drawings,
                lambda prev, d: d.can_follow(prev),
            )
            leaders = []
            for run in runs:
                run[0].members = run if len(run) > 1 else None
                leaders.append(run[0])

        for leader in leaders:
            leader.write_records()

        return leaders

    def prepare_offscreen_mobjects(self, mobjects: Iterable[Mobject]) -> None:
        held = self.offscreen_drawings
        self.offscreen_drawings = dict()
        self.offscreen_leaders = dict()

        candidate_effects: list[Any] = []
        seen_effect_ids: set[int] = set()
        seen_holder_ids: set[int] = set()

        def collect_from_holder(holder: Any) -> None:
            if holder is None or id(holder) in seen_holder_ids:
                return
            seen_holder_ids.add(id(holder))
            for eff in getattr(holder, "get_vfx_list", lambda: [])():
                if id(eff) not in seen_effect_ids:
                    seen_effect_ids.add(id(eff))
                    candidate_effects.append(eff)

        for mobject in mobjects:
            for mob in mobject.get_family():
                collect_from_holder(mob)
                collect_from_holder(getattr(mob, "_vfx_group", None))
                collect_from_holder(getattr(mob, "_vfx_local", None))

        for eff in self.get_frame_vfx_list(mobjects):
            if id(eff) not in seen_effect_ids:
                seen_effect_ids.add(id(eff))
                candidate_effects.append(eff)

        for eff in candidate_effects:
            mask_mob = getattr(eff, "mask", None)
            if mask_mob is None or mask_mob in self.offscreen_leaders:
                continue
            if hasattr(eff, "_ensure_solid_stencil"):
                eff._ensure_solid_stencil(mask_mob)
            self.offscreen_leaders[mask_mob] = self._prepare_offscreen_mobject(mask_mob, held)

    def render_mobject_to_view(
        self,
        encoder: Any,
        mobject: Mobject,
        view: Any,
        load_op: wgpu.LoadOp = wgpu.LoadOp.clear
    ) -> None:
        leaders = self.offscreen_leaders.get(mobject)
        if leaders is None:
            self.gpu.begin_writes()
            leaders = self._prepare_offscreen_mobject(mobject, self.offscreen_drawings)
            self.offscreen_leaders[mobject] = leaders
            self.gpu.end_writes()

        if self.samples > 1:
            att = {
                "color_attachments": [{
                    "view": self.post_processor.msaa_mask_view,
                    "resolve_target": view,
                    "load_op": load_op,
                    "store_op": wgpu.StoreOp.store,
                    "clear_value": (0.0, 0.0, 0.0, 0.0),
                }],
                "depth_stencil_attachment": {
                    "view": self.post_processor.layer_depth_view,
                    "depth_clear_value": 1.0,
                    "depth_load_op": wgpu.LoadOp.clear,
                    "depth_store_op": wgpu.StoreOp.store,
                    "stencil_clear_value": 0,
                    "stencil_load_op": wgpu.LoadOp.clear,
                    "stencil_store_op": wgpu.StoreOp.store,
                },
            }
        else:
            att = {
                "color_attachments": [{
                    "view": view,
                    "load_op": load_op,
                    "store_op": wgpu.StoreOp.store,
                    "clear_value": (0.0, 0.0, 0.0, 0.0),
                }],
                "depth_stencil_attachment": {
                    "view": self.post_processor.layer_depth_view,
                    "depth_clear_value": 1.0,
                    "depth_load_op": wgpu.LoadOp.clear,
                    "depth_store_op": wgpu.StoreOp.store,
                    "stencil_clear_value": 0,
                    "stencil_load_op": wgpu.LoadOp.clear,
                    "stencil_store_op": wgpu.StoreOp.store,
                },
            }
        rp = RenderPass(encoder.begin_render_pass(**att), self.gpu.frame_bind_group)
        for ldr in leaders:
            ldr.draw(rp)
        rp.encoder.end()

    def draw(self, mobjects: Iterable[Mobject], attachments: dict) -> None:
        gpu = self.gpu
        drawings = self.resolve(mobjects)
        if drawings != self.drawn:
            self.bundling.invalidate()
        self.drawn = drawings

        rebinds = gpu.rebinds
        gpu.begin_writes()
        regroup = False
        for drawing in drawings:
            if drawing.write_uniforms():
                regroup = True
            drawing.realize_textures()
            vfx_sig = (
                self.get_vfx_group(drawing.mobject),
                getattr(drawing.mobject, "_vfx_local", None),
            )
            if getattr(drawing, "_vfx_sig", (None, None)) != vfx_sig:
                drawing._vfx_sig = vfx_sig
                regroup = True
                self.bundling.invalidate()
            if drawing.invalidated:
                self.bundling.invalidate()

        if self.bundling.stale or regroup:
            lengths = self.group(drawings)
            if lengths != self.run_lengths:
                self.bundling.invalidate()
            self.run_lengths = lengths

        for leader in self.leaders:
            leader.write_records()
            if leader.invalidated:
                self.bundling.invalidate()
        self.prepare_offscreen_mobjects(mobjects)
        gpu.end_writes()

        if gpu.rebinds != rebinds or gpu.samples != self.samples:
            self.bundling.invalidate()
        self.samples = gpu.samples

        has_any_vfx = any(self.get_vfx_group(leader.mobject) is not None for leader in self.leaders)
        frame_effects = self.get_frame_vfx_list(mobjects)
        has_frame_vfx = len(frame_effects) > 0

        if not has_any_vfx and not has_frame_vfx:
            bundle = self.bundling.take(lambda: gpu.bundle(self.make_draws))
            with gpu.render_pass(attachments) as render_pass:
                if bundle is None:
                    self.make_draws(render_pass)
                else:
                    render_pass.replay(bundle)
            return

        target_view = attachments["color_attachments"][0]["view"]
        final_target = attachments["color_attachments"][0].get("resolve_target") or target_view
        color_tex = getattr(target_view, "texture", getattr(target_view, "_texture", None))
        width = int(color_tex.size[0])
        height = int(color_tex.size[1])
        self.post_processor.resize(width, height)
        self.post_processor.camera = self.camera

        # Avanza el tiempo continuo del pipeline en cada frame
        fps = getattr(self.camera, "fps", 30.0) if self.camera else 30.0
        self.post_processor.time += 1.0 / max(float(fps), 1.0)

        active_frame_effects = [
            e for e in frame_effects
            if getattr(e, "is_active", lambda p: True)(self.post_processor)
        ]

        if not has_any_vfx and not active_frame_effects:
            bundle = self.bundling.take(lambda: gpu.bundle(self.make_draws))
            with gpu.render_pass(attachments) as render_pass:
                if bundle is None:
                    self.make_draws(render_pass)
                else:
                    render_pass.replay(bundle)
            return

        self.bundling.invalidate()

        # -------------------------------------------------------------
        # 1. Agrupamiento contiguo por grupo de VFX optimizado por DAG
        # -------------------------------------------------------------
        ordered_leaders = self.optimize_leaders_dag(self.leaders)
        batches: list[tuple[list[Drawing], Mobject | None]] = []
        curr_batch: list[Drawing] = []
        curr_group: Mobject | None = None
        for leader in ordered_leaders:
            grp = self.get_vfx_group(leader.mobject)
            if not batches:
                curr_batch.append(leader)
                curr_group = grp
                batches.append((curr_batch, curr_group))
            elif grp is curr_group:
                curr_batch.append(leader)
            else:
                curr_batch = [leader]
                curr_group = grp
                batches.append((curr_batch, curr_group))

        # -------------------------------------------------------------
        # 2. UN SOLO COMMAND ENCODER PARA TODO EL FRAME
        # -------------------------------------------------------------
        encoder = gpu.device.create_command_encoder()
        first_draw = True
        clear_color = tuple(attachments["color_attachments"][0]["clear_value"])
        use_scene_buffer = (self.samples > 1) or bool(active_frame_effects)
        accum_view = self.post_processor.scene_view if use_scene_buffer else target_view
        scene_depth_view = attachments["depth_stencil_attachment"]["view"]

        for batch_leaders, group in batches:
            if group is None:
                # Lotes convencionales sin efectos de post-proceso
                if first_draw:
                    if self.samples > 1:
                        pass_att = {
                            "color_attachments": [{
                                "view": target_view,
                                "resolve_target": accum_view,
                                "load_op": wgpu.LoadOp.clear,
                                "store_op": wgpu.StoreOp.store,
                                "clear_value": clear_color,
                            }],
                            "depth_stencil_attachment": {
                                "view": scene_depth_view,
                                "depth_load_op": wgpu.LoadOp.clear,
                                "depth_store_op": wgpu.StoreOp.store,
                                "depth_clear_value": 1.0,
                                "stencil_load_op": wgpu.LoadOp.clear,
                                "stencil_store_op": wgpu.StoreOp.store,
                                "stencil_clear_value": 0,
                            },
                        }
                    else:
                        pass_att = {
                            "color_attachments": [{
                                "view": accum_view,
                                "load_op": wgpu.LoadOp.clear,
                                "store_op": wgpu.StoreOp.store,
                                "clear_value": clear_color,
                            }],
                            "depth_stencil_attachment": {
                                "view": scene_depth_view,
                                "depth_load_op": wgpu.LoadOp.clear,
                                "depth_store_op": wgpu.StoreOp.store,
                                "depth_clear_value": 1.0,
                                "stencil_load_op": wgpu.LoadOp.clear,
                                "stencil_store_op": wgpu.StoreOp.store,
                                "stencil_clear_value": 0,
                            },
                        }
                    rp = RenderPass(encoder.begin_render_pass(**pass_att), gpu.frame_bind_group)
                    for ldr in batch_leaders:
                        ldr.draw(rp)
                    rp.encoder.end()
                    first_draw = False
                else:
                    if self.samples > 1:
                        layer_att = self.post_processor.get_layer_attachments(
                            depth_view=scene_depth_view,
                            clear_color=True,
                            depth_load_op=wgpu.LoadOp.load,
                        )
                        rp = RenderPass(encoder.begin_render_pass(**layer_att), gpu.frame_bind_group)
                        for ldr in batch_leaders:
                            ldr.draw(rp)
                        rp.encoder.end()
                        self.post_processor.blit(encoder, self.post_processor.layer_view, accum_view)
                    else:
                        pass_att = {
                            "color_attachments": [{
                                "view": accum_view,
                                "load_op": wgpu.LoadOp.load,
                                "store_op": wgpu.StoreOp.store,
                                "clear_value": clear_color,
                            }],
                            "depth_stencil_attachment": {
                                "view": scene_depth_view,
                                "depth_load_op": wgpu.LoadOp.load,
                                "depth_store_op": wgpu.StoreOp.store,
                                "depth_clear_value": 1.0,
                                "stencil_load_op": wgpu.LoadOp.load,
                                "stencil_store_op": wgpu.StoreOp.store,
                                "stencil_clear_value": 0,
                            },
                        }
                        rp = RenderPass(encoder.begin_render_pass(**pass_att), gpu.frame_bind_group)
                        for ldr in batch_leaders:
                            ldr.draw(rp)
                        rp.encoder.end()
            else:
                # Lotes que poseen efectos visuales
                if first_draw:
                    if self.samples > 1:
                        clear_pass_msaa = encoder.begin_render_pass(
                            color_attachments=[{
                                "view": target_view,
                                "load_op": wgpu.LoadOp.clear,
                                "store_op": wgpu.StoreOp.store,
                                "clear_value": clear_color,
                            }],
                            depth_stencil_attachment={
                                "view": scene_depth_view,
                                "depth_clear_value": 1.0,
                                "depth_load_op": wgpu.LoadOp.clear,
                                "depth_store_op": wgpu.StoreOp.store,
                                "stencil_clear_value": 0,
                                "stencil_load_op": wgpu.LoadOp.clear,
                                "stencil_store_op": wgpu.StoreOp.store,
                            }
                        )
                        clear_pass_msaa.end()
                        clear_pass_accum = encoder.begin_render_pass(
                            color_attachments=[{
                                "view": accum_view,
                                "load_op": wgpu.LoadOp.clear,
                                "store_op": wgpu.StoreOp.store,
                                "clear_value": clear_color,
                            }]
                        )
                        clear_pass_accum.end()
                    else:
                        clear_pass = encoder.begin_render_pass(
                            color_attachments=[{
                                "view": accum_view,
                                "load_op": wgpu.LoadOp.clear,
                                "store_op": wgpu.StoreOp.store,
                                "clear_value": clear_color,
                            }],
                            depth_stencil_attachment={
                                "view": scene_depth_view,
                                "depth_clear_value": 1.0,
                                "depth_load_op": wgpu.LoadOp.clear,
                                "depth_store_op": wgpu.StoreOp.store,
                                "stencil_clear_value": 0,
                                "stencil_load_op": wgpu.LoadOp.clear,
                                "stencil_store_op": wgpu.StoreOp.store,
                            }
                        )
                        clear_pass.end()
                    first_draw = False

                # Agrupar líderes preservando el orden de profundidad (z-order) entre estáticos y locales
                segments: list[tuple[Mobject | None, list[Drawing]]] = []
                local_segment_map: dict[Mobject, list[Drawing]] = dict()
                for ldr in batch_leaders:
                    local_mob = getattr(ldr.mobject, "_vfx_local", None)
                    if local_mob is not None and local_mob is not group and getattr(local_mob, "has_vfx", lambda: False)():
                        is_active = any(
                            getattr(e, "is_active", lambda p: True)(self.post_processor)
                            for e in local_mob.get_vfx_list()
                        )
                        if is_active:
                            if local_mob in local_segment_map:
                                local_segment_map[local_mob].append(ldr)
                            else:
                                seg_ldrs = [ldr]
                                local_segment_map[local_mob] = seg_ldrs
                                segments.append((local_mob, seg_ldrs))
                            continue
                    if segments and segments[-1][0] is None:
                        segments[-1][1].append(ldr)
                    else:
                        segments.append((None, [ldr]))

                layer_initialized = False
                for local_mob, seg_ldrs in segments:
                    if local_mob is None:
                        if not layer_initialized:
                            layer_att = self.post_processor.get_layer_attachments(
                                depth_view=scene_depth_view,
                                clear_color=True,
                                depth_load_op=wgpu.LoadOp.load,
                            )
                            layer_rp = RenderPass(encoder.begin_render_pass(**layer_att), gpu.frame_bind_group)
                            for ldr in seg_ldrs:
                                ldr.draw(layer_rp)
                            layer_rp.encoder.end()
                            layer_initialized = True
                        elif self.samples > 1:
                            scratch_att = self.post_processor.get_scratch_attachments(
                                depth_view=scene_depth_view,
                                clear_color=True,
                                depth_load_op=wgpu.LoadOp.load,
                            )
                            scratch_rp = RenderPass(encoder.begin_render_pass(**scratch_att), gpu.frame_bind_group)
                            for ldr in seg_ldrs:
                                ldr.draw(scratch_rp)
                            scratch_rp.encoder.end()
                            self.post_processor.blit(encoder, self.post_processor.layer_view_b, self.post_processor.layer_view)
                        else:
                            layer_att = self.post_processor.get_layer_attachments(
                                depth_view=scene_depth_view,
                                clear_color=False,
                                depth_load_op=wgpu.LoadOp.load,
                            )
                            layer_rp = RenderPass(encoder.begin_render_pass(**layer_att), gpu.frame_bind_group)
                            for ldr in seg_ldrs:
                                ldr.draw(layer_rp)
                            layer_rp.encoder.end()
                    else:
                        if not layer_initialized:
                            clear_pass = encoder.begin_render_pass(color_attachments=[{
                                "view": self.post_processor.layer_view,
                                "load_op": wgpu.LoadOp.clear,
                                "store_op": wgpu.StoreOp.store,
                                "clear_value": (0.0, 0.0, 0.0, 0.0),
                            }])
                            clear_pass.end()
                            layer_initialized = True

                        scratch_att = self.post_processor.get_scratch_attachments(
                            depth_view=scene_depth_view,
                            clear_color=True,
                            depth_load_op=wgpu.LoadOp.load,
                        )
                        scratch_rp = RenderPass(encoder.begin_render_pass(**scratch_att), gpu.frame_bind_group)
                        for ldr in seg_ldrs:
                            ldr.draw(scratch_rp)
                        scratch_rp.encoder.end()

                        local_active_effects = sorted(
                            [eff for eff in local_mob.get_vfx_list() if getattr(eff, "is_active", lambda p: True)(self.post_processor)],
                            key=lambda e: getattr(e, "order", 50)
                        )
                        num_local = len(local_active_effects)
                        if num_local == 1:
                            local_active_effects[0].apply(
                                self.post_processor,
                                encoder,
                                self.post_processor.layer_view_b,
                                self.post_processor.layer_view,
                                load_op=wgpu.LoadOp.load,
                            )
                        elif num_local > 1:
                            curr_in = self.post_processor.layer_view_b
                            curr_out = self.post_processor.layer_view_c
                            for idx, eff in enumerate(local_active_effects):
                                is_last = (idx == num_local - 1)
                                dest_view = self.post_processor.layer_view if is_last else curr_out
                                load_op = wgpu.LoadOp.load if is_last else wgpu.LoadOp.clear
                                eff.apply(
                                    self.post_processor,
                                    encoder,
                                    curr_in,
                                    dest_view,
                                    load_op=load_op,
                                )
                                if not is_last:
                                    curr_in, curr_out = curr_out, curr_in

                if not layer_initialized:
                    clear_pass = encoder.begin_render_pass(color_attachments=[{
                        "view": self.post_processor.layer_view,
                        "load_op": wgpu.LoadOp.clear,
                        "store_op": wgpu.StoreOp.store,
                        "clear_value": (0.0, 0.0, 0.0, 0.0),
                    }])
                    clear_pass.end()

                # Snapshot de fondo condicional mediante `needs_bg`
                all_candidate_effects = list(getattr(group, "get_vfx_list", lambda: [])())
                for local_mob in local_segment_map:
                    all_candidate_effects.extend(getattr(local_mob, "get_vfx_list", lambda: [])())

                needs_bg_snapshot = any(
                    getattr(eff, "needs_bg", False)
                    and getattr(eff, "is_active", lambda p: True)(self.post_processor)
                    for eff in all_candidate_effects
                )
                if needs_bg_snapshot:
                    self.post_processor.copy_target_to_bg(encoder, accum_view)

                # Procesar la cadena de efectos del grupo y componer sobre accum_view
                self.post_processor.process_mobject(encoder, accum_view, group)

        if first_draw:
            clear_pass_empty = encoder.begin_render_pass(
                color_attachments=[{
                    "view": accum_view,
                    "load_op": wgpu.LoadOp.clear,
                    "store_op": wgpu.StoreOp.store,
                    "clear_value": clear_color,
                }]
            )
            clear_pass_empty.end()

        # -------------------------------------------------------------
        # 3. Post-procesamiento del frame final, resolución y envío a GPU
        # -------------------------------------------------------------
        if active_frame_effects:
            self.post_processor.process_frame(encoder, accum_view, final_target, active_frame_effects)
        elif self.samples > 1:
            self.post_processor.blit_fullscreen(encoder, accum_view, final_target)

        # Un solo buffer de comandos enviado a la cola del dispositivo
        gpu.queue.submit([encoder.finish()])

    def make_draws(self, render_pass: RenderPass) -> None:
        for leader in self.leaders:
            leader.draw(render_pass)

    def group(self, drawings: list[Drawing]) -> tuple:
        if not self.may_merge:
            self.leaders = list(drawings)
            return (1,) * len(drawings)
        self.compare_uniforms(drawings)
        runs = batch_by_comparison(
            drawings,
            lambda prev, drawing: (
                drawing.can_follow(prev)
                and self.get_vfx_group(prev.mobject) is self.get_vfx_group(drawing.mobject)
                and getattr(prev.mobject, "_vfx_local", None) is getattr(drawing.mobject, "_vfx_local", None)
            )
        )
        self.leaders = []
        lengths = []
        for run in runs:
            run[0].members = run if len(run) > 1 else None
            self.leaders.append(run[0])
            lengths.append(len(run))
        return tuple(lengths)

    def compare_uniforms(self, drawings: list[Drawing]) -> None:
        matching: dict[SharedBuffer, list[bool]] = dict()
        for drawing in drawings:
            buffer = drawing.material.uniform_buffer
            claims = matching.get(buffer)
            if claims is None:
                claims = matching[buffer] = buffer.matching_claims()
            drawing.repeats_uniforms = claims[drawing.uniform_offset // buffer.window]

    def resolve(self, mobjects: Iterable[Mobject]) -> list[Drawing]:
        held = self.drawings
        self.drawings = dict()
        drawn = []
        for mobject in mobjects:
            for mob in mobject.get_family():
                if getattr(mob, "hidden", False):
                    continue
                drawing_class = mob.drawing_class
                if len(mob.data) == 0 or not drawing_class.draws(mob):
                    continue
                drawing = held.get(mob)
                if drawing is None or drawing.replacements is not mob.shader_code_replacements:
                    drawing = drawing_class(self.material_for(mob, drawing_class), mob)
                self.drawings[mob] = drawing
                drawn.append(drawing)

        # Ordenamiento de dibujo:
        # En gráficos 3D, los objetos opacos se renderizan primero con depth write,
        # y los objetos transparentes se renderizan después con depth test pero sin depth write,
        # para que las superficies transparentes tiñan suavemente la geometría situada detrás de ellas.
        if len(drawn) > 1:
            drawn.sort(key=lambda d: d.mobject.z_index)
            if any(d.mobject.depth_test for d in drawn):
                frame = getattr(self.camera, "frame", None)
                phi = frame.get_phi() if frame is not None else 0.0
                theta = frame.get_theta() if frame is not None else 0.0
                if abs(phi) > 1e-3 or abs(theta) > 1e-3:
                    cam_pos = frame.get_implied_camera_location() if frame is not None else np.array([0.0, 0.0, 10.0])
                    cx, cy, cz = float(cam_pos[0]), float(cam_pos[1]), float(cam_pos[2])

                    def depth_sort_key(d: Drawing):
                        mob = d.mobject
                        is_transparent = 0 if getattr(mob, "is_opaque", lambda: True)() else 1
                        c = mob.get_center()
                        dx = c[0] - cx
                        dy = c[1] - cy
                        dz = c[2] - cz
                        return (mob.z_index, is_transparent, -(dx * dx + dy * dy + dz * dz))
                else:
                    def depth_sort_key(d: Drawing):
                        mob = d.mobject
                        is_transparent = 0 if getattr(mob, "is_opaque", lambda: True)() else 1
                        return (mob.z_index, is_transparent)

                depth_indices = [i for i, d in enumerate(drawn) if d.mobject.depth_test]
                depth_drawings = [drawn[i] for i in depth_indices]
                depth_drawings.sort(key=depth_sort_key)
                for idx, d in zip(depth_indices, depth_drawings):
                    drawn[idx] = d

        return drawn

    def material_for(self, mobject: Mobject, drawing_class: type) -> Material:
        key = drawing_class.key(mobject)
        if key not in self.materials:
            self.materials[key] = Material(
                self.gpu, mobject, drawing_class.module_specs(mobject),
            )
        return self.materials[key]
