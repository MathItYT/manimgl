from __future__ import annotations

import numpy as np
from PIL import Image

from manimlib.constants import DL, DR, UL, UR
from manimlib.mobject.mobject import Mobject
from manimlib.renderer.texture import ImageFile
from manimlib.utils.bezier import inverse_interpolate
from manimlib.utils.images import get_full_raster_image_path
from manimlib.utils.iterables import listify
from manimlib.utils.iterables import resize_with_interpolation

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Sequence, Tuple
    from manimlib.renderer.texture import TextureSource
    from manimlib.typing import Vect3


class ImageMobject(Mobject):
    shader_file: str = "image.wgsl"
    data_dtype: np.dtype = np.dtype([
        ('point', np.float32, (3,)),
        ('im_coords', np.float32, (2,)),
        ('opacity', np.float32, (1,)),
    ])
    # The four corners are expanded into the two triangles covering them by the vertex
    # shader, six of the vertices drawn doing that and the rest collapsing
    verts_per_record: int = 6

    def __init__(
        self,
        filename: str,
        height: float = 4.0,
        **kwargs
    ):
        self.height = height
        super().__init__(textures={"Texture": self.init_texture(filename)}, **kwargs)

    def init_texture(self, filename: str) -> TextureSource:
        """
        Where the pixels drawn over the four corners come from, which for an image is the
        file itself. Overridden by anything drawing the same quad from somewhere else, a
        frame of a video say, see VideoMobject.
        """
        self.image_path = get_full_raster_image_path(filename)
        self.image = Image.open(self.image_path)
        return ImageFile(self.image_path)

    def init_data(self) -> None:
        super().init_data(length=4)
        self.data["point"] = [UL, DL, UR, DR]
        self.data["im_coords"] = [(0, 0), (0, 1), (1, 0), (1, 1)]
        self.data["opacity"] = self.opacity

    def get_source_size(self) -> Tuple[int, int]:
        """The pixel size of what is drawn, which is what fixes the aspect ratio"""
        return self.image.size

    def init_points(self) -> None:
        width, height = self.get_source_size()
        self.set_width(2 * width / height, stretch=True)
        self.set_height(self.height)

    def set_opacity(self, opacity: float, recurse: bool = True):
        with self.data.being_written() as data:
            data["opacity"][:, 0] = resize_with_interpolation(
                np.array(listify(opacity)),
                self.get_num_points()
            )
        return self

    def set_color(self, color, opacity=None, recurse=None):
        return self

    def point_to_rgb(self, point: Vect3) -> Vect3:
        x0, y0 = self.get_corner(UL)[:2]
        x1, y1 = self.get_corner(DR)[:2]
        x_alpha = inverse_interpolate(x0, x1, point[0])
        y_alpha = inverse_interpolate(y0, y1, point[1])
        if not (0 <= x_alpha <= 1) and (0 <= y_alpha <= 1):
            # TODO, raise smarter exception
            raise Exception("Cannot sample color from outside an image")

        pw, ph = self.image.size
        rgb = self.image.getpixel((
            int((pw - 1) * x_alpha),
            int((ph - 1) * y_alpha),
        ))[:3]
        return np.array(rgb) / 255
